import React, { useState, useEffect, useRef } from 'react';
import { initializeApp } from 'firebase/app';
import { getAuth, signInWithPopup, GoogleAuthProvider, onAuthStateChanged, User } from 'firebase/auth';
import { motion, AnimatePresence } from 'motion/react';
import * as XLSX from 'xlsx';
import JSZip from 'jszip';
import { 
  FileCheck, 
  FileWarning, 
  Upload, 
  Plus, 
  Database, 
  LogOut, 
  ExternalLink, 
  FileText, 
  CheckCircle2, 
  AlertTriangle, 
  RefreshCw, 
  Search, 
  FileSpreadsheet, 
  HelpCircle,
  TrendingUp,
  AlertCircle,
  Layers,
  Trash2,
  RotateCcw,
  Clock,
  Download,
  XCircle,
  CheckCheck
} from 'lucide-react';
import { DatabaseState, ProcessedInvoice, PurchaseOrder, GoodsReceivedNote, MatchingResult } from './types';
import { INITIAL_MOCK_DATABASE, performMatching, getDaysBetween, normalizePONumber, parseExcelInvoiceData } from './utils';
import firebaseConfig from '../firebase-applet-config.json';

// Initialize Firebase
const app = initializeApp(firebaseConfig);
const auth = getAuth(app);
const provider = new GoogleAuthProvider();
// Request Sheets scopes
provider.addScope('https://www.googleapis.com/auth/spreadsheets');
provider.addScope('https://www.googleapis.com/auth/spreadsheets.readonly');

const DEFAULT_SPREADSHEET_ID = '1gruFXgzBQVzIalBdqaPTRGBfHpOm50fJuV7_K0hDGcQ';

export default function App() {
  // Authentication & Sheet Connection states
  const [user, setUser] = useState<User | null>(null);
  const [token, setToken] = useState<string | null>(null);
  const [isLoggingIn, setIsLoggingIn] = useState(false);
  const [sheetInput, setSheetInput] = useState('');
  const [connectedSheetId, setConnectedSheetId] = useState<string | null>(null);
  const [isSheetLoading, setIsSheetLoading] = useState(false);
  const [sheetError, setSheetError] = useState<string | null>(null);

  // Active database state (either mock or loaded from Sheets)
  const [db, setDb] = useState<DatabaseState>(INITIAL_MOCK_DATABASE);
  const [isLocalMode, setIsLocalMode] = useState(true);

  // Form states for new invoice submission
  const [inputMode, setInputMode] = useState<'upload' | 'manual' | 'batch'>('upload');
  const [file, setFile] = useState<File | null>(null);
  const [filePreview, setFilePreview] = useState<string | null>(null);
  const [isParsing, setIsParsing] = useState(false);
  const [parseError, setParseError] = useState<string | null>(null);

  // Batch states
  interface BatchItem {
    filename: string;
    invoiceNumber: string;
    supplier: string;
    poNumber: string;
    invoiceAmount: number;
    quantityInvoiced: number;
    unitPrice: number;
    status: 'Cleared' | 'Flagged' | 'Failed';
    reason: string;
    base64Data?: string;
    mimeType?: string;
    textContent?: string;
  }
  const [batchItems, setBatchItems] = useState<BatchItem[]>([]);
  const [isProcessingBatch, setIsProcessingBatch] = useState(false);
  const [batchProgress, setBatchProgress] = useState({ current: 0, total: 0 });
  const [batchProgressTitle, setBatchProgressTitle] = useState('Processing ZIP Archive...');
  const [consecutive429s, setConsecutive429s] = useState(0);

  // Invoice form fields
  const [invoiceNumber, setInvoiceNumber] = useState('');
  const [supplier, setSupplier] = useState('');
  const [poNumber, setPoNumber] = useState('');
  const [quantityInvoiced, setQuantityInvoiced] = useState<number | ''>('');
  const [unitPrice, setUnitPrice] = useState<number | ''>('');
  const [invoiceAmount, setInvoiceAmount] = useState<number | ''>('');

  // Matching check states
  const [matchingResult, setMatchingResult] = useState<MatchingResult | null>(null);
  const [hasChecked, setHasChecked] = useState(false);
  const [isMatchingLoading, setIsMatchingLoading] = useState(false);
  const [actionSuccess, setActionSuccess] = useState<string | null>(null);

  // UI state
  const [activeTab, setActiveTab] = useState<'po' | 'grn' | 'invoices' | 'threeway'>('threeway');
  const [isExporting, setIsExporting] = useState(false);
  const [statusFilter, setStatusFilter] = useState<'all' | 'pending' | 'cleared' | 'flagged'>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [showHelp, setShowHelp] = useState(false);
  const [lastRefreshedTime, setLastRefreshedTime] = useState<string | null>(null);

  // Custom iframe-safe confirmation modal state
  const [confirmModal, setConfirmModal] = useState<{
    isOpen: boolean;
    title: string;
    message: string;
    onConfirm: () => void;
  } | null>(null);

  // File Upload Drag states
  const [isDragging, setIsDragging] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Load local database and sheets config on start
  useEffect(() => {
    // Check local storage for persistent mock data and sheet ID
    const savedDb = localStorage.getItem('ap_matching_db');
    if (savedDb) {
      try {
        setDb(JSON.parse(savedDb));
      } catch (e) {
        console.error('Error parsing saved database, using default');
      }
    } else {
      localStorage.setItem('ap_matching_db', JSON.stringify(INITIAL_MOCK_DATABASE));
    }

    const savedSheetId = localStorage.getItem('ap_connected_sheet_id') || DEFAULT_SPREADSHEET_ID;
    setConnectedSheetId(savedSheetId);
    setSheetInput(savedSheetId);

    // Initialize Auth state
    const unsubscribe = onAuthStateChanged(auth, async (currentUser) => {
      if (currentUser) {
        setUser(currentUser);
      } else {
        setUser(null);
        setToken(null);
        setIsLocalMode(true);
      }
    });

    return () => unsubscribe();
  }, []);

  // Auto-refresh interval (30 seconds) to poll latest invoices from Google Sheets
  useEffect(() => {
    if (!token) return;

    const targetSheetId = connectedSheetId || DEFAULT_SPREADSHEET_ID;

    // Run initial load upon token acquisition
    loadSheetData(targetSheetId, token, false);

    // Poll every 30 seconds
    const interval = setInterval(() => {
      loadSheetData(targetSheetId, token, true);
    }, 30000);

    return () => clearInterval(interval);
  }, [token, connectedSheetId]);

  // Save local DB to localstorage whenever it changes
  const saveLocalDb = (newDb: DatabaseState) => {
    setDb(newDb);
    localStorage.setItem('ap_matching_db', JSON.stringify(newDb));
  };

  // Google Login Flow
  const handleLogin = async () => {
    setIsLoggingIn(true);
    setSheetError(null);
    try {
      const result = await signInWithPopup(auth, provider);
      const credential = GoogleAuthProvider.credentialFromResult(result);
      if (credential?.accessToken) {
        const accessToken = credential.accessToken;
        setToken(accessToken);
        setUser(result.user);
        setIsLocalMode(false);
        const targetSheet = connectedSheetId || DEFAULT_SPREADSHEET_ID;
        setConnectedSheetId(targetSheet);
        setSheetInput(targetSheet);
        loadSheetData(targetSheet, accessToken, false);
      } else {
        throw new Error('Could not retrieve Google Access Token');
      }
    } catch (err: any) {
      console.error('Login failed:', err);
      setSheetError(`Sign-in failed: ${err.message || err}`);
    } finally {
      setIsLoggingIn(false);
    }
  };

  const handleLogout = async () => {
    try {
      await auth.signOut();
      setUser(null);
      setToken(null);
      setConnectedSheetId(null);
      setIsLocalMode(true);
      setSheetInput('');
      localStorage.removeItem('ap_connected_sheet_id');
      // Revert active database to what is in local storage
      const savedDb = localStorage.getItem('ap_matching_db');
      if (savedDb) {
        setDb(JSON.parse(savedDb));
      }
    } catch (err) {
      console.error('Logout failed:', err);
    }
  };

  // Extract Spreadsheet ID from input (supports pasting full URL or simple ID)
  const extractSpreadsheetId = (input: string): string => {
    const trimmed = input.trim();
    if (trimmed.includes('docs.google.com/spreadsheets')) {
      const match = trimmed.match(/\/d\/([a-zA-Z0-9-_]+)/);
      return match ? match[1] : trimmed;
    }
    return trimmed;
  };

  // Flexible parser for AP Invoices / Processed Invoices worksheet tabs
  const parseFlexibleInvoicesSheet = (values: any[][]): ProcessedInvoice[] => {
    if (!values || values.length <= 1) return [];
    const headers = values[0].map((h: any) => h?.toString().trim().toLowerCase() || '');

    const findIdx = (candidates: string[]) => {
      return headers.findIndex(h => candidates.some(c => h.includes(c)));
    };

    const invIdx = findIdx(['invoice_number', 'invoice number', 'invoicenumber', 'invoice', 'inv', 'inv_no', 'invoice_id', 'invoice #', 'inv #']);
    const suppIdx = findIdx(['supplier', 'supplier_name', 'supplier name', 'vendor', 'vendor_name', 'company', 'biller']);
    const poIdx = findIdx(['po_number', 'po number', 'ponumber', 'po', 'po_no', 'purchase_order', 'ref_po', 'po #', 'po_num', 'p.o. #', 'p.o. number', 'purchase order', 'po_id']);
    const qtyIdx = findIdx(['quantity_invoiced', 'quantity invoiced', 'quantity', 'qty', 'count', 'billed_qty']);
    const priceIdx = findIdx(['unit_price', 'unit price', 'price', 'rate', 'unit_cost', 'cost']);
    const amtIdx = findIdx(['invoice_amount', 'invoice amount', 'amount', 'total', 'total_amount', 'subtotal', 'billed_amount']);
    const dateIdx = findIdx(['date_processed', 'date processed', 'date', 'invoice_date', 'date_invoiced', 'created_at']);
    const statusIdx = findIdx(['matchstatus', 'match status', 'status', 'state', 'match']);
    const explIdx = findIdx(['explanation', 'reason', 'notes', 'comments', 'discrepancy']);
    const actionIdx = findIdx(['followupaction', 'follow up action', 'action', 'next_step']);

    return values.slice(1).map((row, index) => {
      const rawInv = invIdx !== -1 && row[invIdx] !== undefined ? row[invIdx].toString().trim() : '';
      const rawSupp = suppIdx !== -1 && row[suppIdx] !== undefined ? row[suppIdx].toString().trim() : '';
      const rawPo = poIdx !== -1 && row[poIdx] !== undefined ? row[poIdx].toString().trim() : '';
      const rawQty = qtyIdx !== -1 && row[qtyIdx] !== undefined ? parseInt(row[qtyIdx].toString().replace(/[^0-9.-]/g, ''), 10) : 0;
      const rawPrice = priceIdx !== -1 && row[priceIdx] !== undefined ? parseFloat(row[priceIdx].toString().replace(/[^0-9.-]/g, '')) : 0;
      let rawAmt = amtIdx !== -1 && row[amtIdx] !== undefined ? parseFloat(row[amtIdx].toString().replace(/[^0-9.-]/g, '')) : 0;

      if (!rawAmt && rawQty && rawPrice) {
        rawAmt = rawQty * rawPrice;
      }

      const rawDate = dateIdx !== -1 && row[dateIdx] !== undefined ? row[dateIdx].toString().trim() : new Date().toISOString().split('T')[0];
      const rawStatus = statusIdx !== -1 && row[statusIdx] !== undefined ? row[statusIdx].toString().trim().toLowerCase() : '';

      let matchStatus: 'Pending' | 'Cleared' | 'Flagged' | 'Failed' = 'Pending';
      if (rawStatus.includes('cleared') || rawStatus.includes('approved') || rawStatus.includes('matched')) {
        matchStatus = 'Cleared';
      } else if (rawStatus.includes('flagged') || rawStatus.includes('variance') || rawStatus.includes('discrepancy')) {
        matchStatus = 'Flagged';
      } else if (rawStatus.includes('failed') || rawStatus.includes('rejected')) {
        matchStatus = 'Failed';
      } else {
        matchStatus = 'Pending';
      }

      const explanation = explIdx !== -1 && row[explIdx] !== undefined ? row[explIdx].toString().trim() : '';
      const followUpAction = actionIdx !== -1 && row[actionIdx] !== undefined ? row[actionIdx].toString().trim() : '';

      return {
        Invoice_Number: rawInv || `INV-ROW-${index + 1}`,
        Supplier: rawSupp || 'Unknown Supplier',
        Invoice_Amount: isNaN(rawAmt) ? 0 : rawAmt,
        Quantity_Invoiced: isNaN(rawQty) ? 0 : rawQty,
        Unit_Price: isNaN(rawPrice) ? 0 : rawPrice,
        PO_Number: rawPo ? normalizePONumber(rawPo) : '',
        Date_Processed: rawDate || new Date().toISOString().split('T')[0],
        MatchStatus: matchStatus,
        Explanation: explanation,
        FollowUpAction: followUpAction,
      };
    }).filter(i => Boolean(i.Invoice_Number || i.Supplier || i.PO_Number || i.Invoice_Amount > 0));
  };

  // Load data from Google Sheet tabs (supports AP Invoices worksheet tab)
  const loadSheetData = async (sheetId: string, accessToken: string, isSilent = false) => {
    if (!isSilent) {
      setIsSheetLoading(true);
      setSheetError(null);
    }
    try {
      // 1. Fetch spreadsheet metadata to verify sheets exist
      const metaRes = await fetch(`https://sheets.googleapis.com/v4/spreadsheets/${sheetId}`, {
        headers: { Authorization: `Bearer ${accessToken}` },
      });
      if (!metaRes.ok) {
        const errorData = await metaRes.json();
        throw new Error(errorData.error?.message || 'Failed to access Google Sheet. Check permissions or ID.');
      }
      const meta = await metaRes.json();
      const sheetTitles: string[] = meta.sheets?.map((s: any) => s.properties?.title) || [];

      // 2. Fetch data from each available sheet tab
      const fetchRange = async (range: string) => {
        try {
          const res = await fetch(`https://sheets.googleapis.com/v4/spreadsheets/${sheetId}/values/${encodeURIComponent(range)}`, {
            headers: { Authorization: `Bearer ${accessToken}` },
          });
          if (!res.ok) return [];
          const data = await res.json();
          return data.values || [];
        } catch {
          return [];
        }
      };

      const hasAPInvoices = sheetTitles.includes('AP Invoices');
      const hasProcessedInvoices = sheetTitles.includes('Processed Invoices');
      const hasPOs = sheetTitles.includes('Purchase Orders');
      const hasGRNs = sheetTitles.includes('Goods Received Notes');

      const [apInvoiceValues, processedInvoiceValues, poValues, grnValues] = await Promise.all([
        hasAPInvoices ? fetchRange('AP Invoices!A1:Z1000') : Promise.resolve([]),
        hasProcessedInvoices ? fetchRange('Processed Invoices!A1:Z1000') : Promise.resolve([]),
        hasPOs ? fetchRange('Purchase Orders!A1:Z1000') : Promise.resolve([]),
        hasGRNs ? fetchRange('Goods Received Notes!A1:Z1000') : Promise.resolve([]),
      ]);

      // Fallback: if neither AP Invoices nor Processed Invoices tab exists, read first sheet tab
      let fallbackInvoiceValues: any[][] = [];
      if (!hasAPInvoices && !hasProcessedInvoices && sheetTitles.length > 0) {
        fallbackInvoiceValues = await fetchRange(`${sheetTitles[0]}!A1:Z1000`);
      }

      // 3. Parse spreadsheet values into typed objects
      const parseSheetRows = <T,>(values: any[][], expectedHeaders: string[]): T[] => {
        if (!values || values.length <= 1) return [];
        const sheetHeaders = values[0].map((h: any) => h?.toString().trim().toLowerCase());
        
        return values.slice(1).map(row => {
          const obj: any = {};
          expectedHeaders.forEach(header => {
            const index = sheetHeaders.indexOf(header.toLowerCase());
            const val = index !== -1 ? row[index] : '';
            
            if (header.includes('Quantity') || header.includes('Ordered') || header.includes('Received')) {
              obj[header] = parseInt(val) || 0;
            } else if (header.includes('Price') || header.includes('Amount')) {
              obj[header] = parseFloat(val) || 0;
            } else {
              obj[header] = val !== undefined ? val.toString().trim() : '';
            }
          });
          return obj as T;
        });
      };

      const purchaseOrders = hasPOs ? parseSheetRows<PurchaseOrder>(poValues, [
        'PO_Number', 'Supplier', 'Item', 'Quantity_Ordered', 'Unit_Price'
      ]) : db.purchaseOrders;

      const goodsReceivedNotes = hasGRNs ? parseSheetRows<GoodsReceivedNote>(grnValues, [
        'GRN_Number', 'PO_Number', 'Quantity_Received', 'Date_Received'
      ]) : db.goodsReceivedNotes;

      // Extract invoices from AP Invoices and Processed Invoices
      const rawInvoices: ProcessedInvoice[] = [];
      if (apInvoiceValues.length > 0) {
        rawInvoices.push(...parseFlexibleInvoicesSheet(apInvoiceValues));
      }
      if (processedInvoiceValues.length > 0) {
        const parsedProc = parseFlexibleInvoicesSheet(processedInvoiceValues);
        for (const p of parsedProc) {
          if (!rawInvoices.some(existing => existing.Invoice_Number.trim().toLowerCase() === p.Invoice_Number.trim().toLowerCase())) {
            rawInvoices.push(p);
          }
        }
      }
      if (rawInvoices.length === 0 && fallbackInvoiceValues.length > 0) {
        rawInvoices.push(...parseFlexibleInvoicesSheet(fallbackInvoiceValues));
      }

      // Track scan logs and status counters
      const scanLogs: string[] = [];
      let clearedCount = 0;
      let flaggedCount = 0;
      let pendingCount = 0;

      // Automatically compute 3-way matching for all rows without stopping on single-row failures
      const processedInvoices: ProcessedInvoice[] = rawInvoices.map((inv, idx) => {
        try {
          const matchRes = performMatching(inv, { purchaseOrders, goodsReceivedNotes, processedInvoices: [] });

          let status: ProcessedInvoice['MatchStatus'] = inv.MatchStatus;
          if (!status || status === 'Pending') {
            status = matchRes.status;
          }

          if (status === 'Cleared') clearedCount++;
          else if (status === 'Flagged') flaggedCount++;
          else pendingCount++;

          return {
            ...inv,
            PO_Number: inv.PO_Number || (matchRes.poDetails ? matchRes.poDetails.PO_Number : ''),
            Explanation: inv.Explanation && inv.Explanation.length > 5 && !inv.Explanation.includes('Purchase Order not found') ? inv.Explanation : matchRes.explanation,
            FollowUpAction: inv.FollowUpAction || matchRes.followUp,
            MatchStatus: status
          };
        } catch (err: any) {
          const logMsg = `Row ${idx + 2} (${inv.Invoice_Number || 'No ID'}): ${err.message || 'Verification error'}`;
          console.error('Scan error on row:', logMsg);
          scanLogs.push(logMsg);
          flaggedCount++;
          return {
            ...inv,
            MatchStatus: 'Flagged' as const,
            Explanation: `Row Scan Warning: ${err.message || 'Row verification error'}`,
            FollowUpAction: 'Please verify row format in Google Sheet.'
          };
        }
      });

      if (isSilent) {
        setDb(prevDb => {
          const prevStr = JSON.stringify(prevDb.processedInvoices);
          const newStr = JSON.stringify(processedInvoices);

          if (prevStr !== newStr) {
            const newPending = processedInvoices.filter(i => i.MatchStatus === 'Pending').length;
            setActionSuccess(`✨ Auto-reloaded Google Sheet ("AP Invoices"): Dashboard refreshed with latest pending invoice data (${newPending} pending).`);
            return { purchaseOrders, goodsReceivedNotes, processedInvoices };
          }
          return prevDb;
        });
      } else {
        setDb({ purchaseOrders, goodsReceivedNotes, processedInvoices });
        const summaryMsg = `Scanned ${processedInvoices.length} total invoice row(s) from sheet: ${clearedCount} Cleared (3-Way Matched), ${flaggedCount} Flagged discrepancies${pendingCount > 0 ? `, ${pendingCount} Pending` : ''}.${scanLogs.length > 0 ? ` Sync warnings logged on ${scanLogs.length} row(s): ${scanLogs.join(' | ')}` : ''}`;
        setActionSuccess(summaryMsg);
      }

      setConnectedSheetId(sheetId);
      setSheetInput(sheetId);
      setIsLocalMode(false);
      localStorage.setItem('ap_connected_sheet_id', sheetId);
      setLastRefreshedTime(new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' }));
    } catch (err: any) {
      console.error('Error loading sheets:', err);
      if (!isSilent) {
        setSheetError(err.message || 'An unexpected error occurred while loading sheet data.');
      }
    } finally {
      if (!isSilent) {
        setIsSheetLoading(false);
      }
    }
  };

  const handleConnectSheet = () => {
    const id = extractSpreadsheetId(sheetInput);
    if (!id) {
      setSheetError('Please enter a valid spreadsheet URL or ID');
      return;
    }
    if (!token) {
      // Prompt sign in
      handleLogin();
    } else {
      loadSheetData(id, token);
    }
  };

  // Create a brand new seeded Spreadsheet in user's Drive
  const handleCreateTemplateSheet = async () => {
    if (!token) {
      setSheetError('Please sign in with Google first.');
      return;
    }
    setIsSheetLoading(true);
    setSheetError(null);

    try {
      // 1. Create Spreadsheet
      const response = await fetch('https://sheets.googleapis.com/v4/spreadsheets', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({
          properties: {
            title: 'AP 3-Way Match Database (Hardware Supply SME)',
          },
          sheets: [
            { properties: { title: 'Purchase Orders' } },
            { properties: { title: 'Goods Received Notes' } },
            { properties: { title: 'AP Invoices' } },
            { properties: { title: 'Processed Invoices' } },
          ],
        }),
      });

      if (!response.ok) {
        throw new Error('Failed to create new spreadsheet.');
      }

      const sheetMeta = await response.json();
      const newSheetId = sheetMeta.spreadsheetId;

      // 2. Populate Headers and Mock Rows for each Sheet tab
      const populateTab = async (tabName: string, values: any[][]) => {
        await fetch(`https://sheets.googleapis.com/v4/spreadsheets/${newSheetId}/values/${encodeURIComponent(tabName)}!A1?valueInputOption=USER_ENTERED`, {
          method: 'PUT',
          headers: {
            'Content-Type': 'application/json',
            Authorization: `Bearer ${token}`,
          },
          body: JSON.stringify({ values }),
        });
      };

      // Purchase Orders data
      const poRows = [
        ['PO_Number', 'Supplier', 'Item', 'Quantity_Ordered', 'Unit_Price'],
        ...INITIAL_MOCK_DATABASE.purchaseOrders.map(p => [p.PO_Number, p.Supplier, p.Item, p.Quantity_Ordered, p.Unit_Price])
      ];

      // Goods Received Notes data
      const grnRows = [
        ['GRN_Number', 'PO_Number', 'Quantity_Received', 'Date_Received'],
        ...INITIAL_MOCK_DATABASE.goodsReceivedNotes.map(g => [g.GRN_Number, g.PO_Number, g.Quantity_Received, g.Date_Received])
      ];

      // Invoices data (used for both AP Invoices and Processed Invoices)
      const invoiceRows = [
        ['Invoice_Number', 'Supplier', 'Invoice_Amount', 'Quantity_Invoiced', 'Unit_Price', 'PO_Number', 'Date_Processed', 'MatchStatus', 'Explanation', 'FollowUpAction'],
        ...INITIAL_MOCK_DATABASE.processedInvoices.map(i => [i.Invoice_Number, i.Supplier, i.Invoice_Amount, i.Quantity_Invoiced, i.Unit_Price, i.PO_Number, i.Date_Processed, i.MatchStatus, i.Explanation, i.FollowUpAction])
      ];

      await Promise.all([
        populateTab('Purchase Orders', poRows),
        populateTab('Goods Received Notes', grnRows),
        populateTab('AP Invoices', invoiceRows),
        populateTab('Processed Invoices', invoiceRows),
      ]);

      // Automatically connect and load
      setSheetInput(newSheetId);
      await loadSheetData(newSheetId, token);
      setActionSuccess('Perfect! A brand new seeded Google Sheet database has been created and connected to your account.');
    } catch (err: any) {
      console.error(err);
      setSheetError(err.message || 'Failed to create template spreadsheet.');
    } finally {
      setIsSheetLoading(false);
    }
  };

  const handleClearAllRecords = () => {
    setConfirmModal({
      isOpen: true,
      title: 'Clear All Database Records?',
      message: 'Are you sure you want to clear all data? This will empty all Purchase Orders (POs), Goods Received Notes (GRNs), and Processed Invoices. This action cannot be undone.',
      onConfirm: async () => {
        setConfirmModal(null);
        const emptyDb: DatabaseState = {
          purchaseOrders: [],
          goodsReceivedNotes: [],
          processedInvoices: []
        };

        if (isLocalMode) {
          saveLocalDb(emptyDb);
          setActionSuccess('Successfully cleared all local Purchase Orders, Goods Received Notes, and Processed Invoices!');
        } else {
          if (!token || !connectedSheetId) {
            alert('Authentication lost. Reverting to local practice mode and clearing.');
            saveLocalDb(emptyDb);
            setIsLocalMode(true);
            setConnectedSheetId(null);
            return;
          }

          setIsSheetLoading(true);
          try {
            // Clear ranges on Google Sheets
            const clearRange = async (range: string) => {
              await fetch(`https://sheets.googleapis.com/v4/spreadsheets/${connectedSheetId}/values/${encodeURIComponent(range)}:clear`, {
                method: 'POST',
                headers: {
                  Authorization: `Bearer ${token}`,
                },
              });
            };

            // Write empty headers back to keep them functional
            const updateHeaders = async (range: string, headers: string[]) => {
              await fetch(`https://sheets.googleapis.com/v4/spreadsheets/${connectedSheetId}/values/${encodeURIComponent(range)}?valueInputOption=USER_ENTERED`, {
                method: 'PUT',
                headers: {
                  'Content-Type': 'application/json',
                  Authorization: `Bearer ${token}`,
                },
                body: JSON.stringify({ values: [headers] }),
              });
            };

            await Promise.all([
              clearRange('Purchase Orders!A1:E1000'),
              clearRange('Goods Received Notes!A1:D1000'),
              clearRange('Processed Invoices!A1:J1000'),
            ]);

            await Promise.all([
              updateHeaders('Purchase Orders!A1', ['PO_Number', 'Supplier', 'Item', 'Quantity_Ordered', 'Unit_Price']),
              updateHeaders('Goods Received Notes!A1', ['GRN_Number', 'PO_Number', 'Quantity_Received', 'Date_Received']),
              updateHeaders('Processed Invoices!A1', ['Invoice_Number', 'Supplier', 'Invoice_Amount', 'Quantity_Invoiced', 'Unit_Price', 'PO_Number', 'Date_Processed', 'MatchStatus', 'Explanation', 'FollowUpAction']),
            ]);

            setDb(emptyDb);
            setActionSuccess('Successfully cleared all Google Sheets tabs and local database records!');
          } catch (err: any) {
            console.error('Error clearing Google Sheet:', err);
            alert(`Failed to clear Google Sheet: ${err.message || err}. Clearing local database instead.`);
            saveLocalDb(emptyDb);
          } finally {
            setIsSheetLoading(false);
          }
        }

        setMatchingResult(null);
        setHasChecked(false);
      }
    });
  };

  const handleResetSampleData = () => {
    setConfirmModal({
      isOpen: true,
      title: 'Reset to SME Sample Data?',
      message: 'Are you sure you want to reset all data back to the default SME hardware sample records? This will overwrite your current changes.',
      onConfirm: () => {
        setConfirmModal(null);
        if (isLocalMode) {
          saveLocalDb(INITIAL_MOCK_DATABASE);
          setActionSuccess('Successfully restored all tables back to the default SME sample records!');
        } else {
          alert('You are currently connected to Google Sheets. Disconnect from Google Sheets to reset local practice database, or use "Create Template Sheet" to seed a fresh sheet.');
        }

        setMatchingResult(null);
        setHasChecked(false);
      }
    });
  };

  // Auto-calculate invoice amount based on quantity & price
  const handleQuantityOrPriceChange = (qty: number | '', price: number | '') => {
    if (qty !== '' && price !== '') {
      setInvoiceAmount(parseFloat((qty * price).toFixed(2)));
    }
  };

  // File Upload Handlers
  const triggerFileSelect = () => {
    setParseError(null);
    fileInputRef.current?.click();
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      processUploadedFile(e.target.files[0]);
    }
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(true);
    setParseError(null);
  };

  const handleDragLeave = () => {
    setIsDragging(false);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      processUploadedFile(e.dataTransfer.files[0]);
    }
  };

  const processUploadedFile = (uploadedFile: File) => {
    const ext = uploadedFile.name.split('.').pop()?.toLowerCase() || '';
    const validExtensions = ['pdf', 'jpeg', 'jpg', 'png', 'xlsx', 'xls', 'csv'];
    const validTypes = [
      'application/pdf',
      'image/jpeg',
      'image/png',
      'image/jpg',
      'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
      'application/vnd.ms-excel',
      'text/csv'
    ];

    if (!validTypes.includes(uploadedFile.type) && !validExtensions.includes(ext)) {
      setParseError('Unsupported file type. Please upload a PDF, Image (JPG/PNG), Excel (.xlsx/.xls), or CSV sheet.');
      return;
    }
    setFile(uploadedFile);
    setParseError(null);

    // Create preview
    if (uploadedFile.type.startsWith('image/')) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setFilePreview(reader.result as string);
      };
      reader.readAsDataURL(uploadedFile);
    } else {
      setFilePreview(null); // PDF / Excel placeholder
    }

    // Auto-parse using Gemini or Excel parser
    parseInvoiceWithGemini(uploadedFile);
  };

  // Convert File to Base64
  const fileToBase64 = (file: File): Promise<string> => {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.readAsDataURL(file);
      reader.onload = () => {
        const base64String = (reader.result as string).split(',')[1];
        resolve(base64String);
      };
      reader.onerror = (error) => reject(error);
    });
  };

  // Parse invoice with server-side Gemini using retry with exponential backoff / user-requested delays
  const parseInvoiceWithRetry = async (
    payload: string | { base64Data?: string; mimeType?: string; textContent?: string },
    mimeTypeOrMaxRetries?: string | number,
    maxRetriesParam = 2,
    delayMsParam = 10000
  ): Promise<any> => {
    let bodyData: any = {};
    let maxRetries = maxRetriesParam;
    let delayMs = delayMsParam;

    if (typeof payload === 'string') {
      bodyData = { base64Data: payload, mimeType: mimeTypeOrMaxRetries as string };
    } else {
      bodyData = payload;
      if (typeof mimeTypeOrMaxRetries === 'number') {
        maxRetries = mimeTypeOrMaxRetries;
      }
    }

    let lastError: any = null;

    for (let attempt = 0; attempt < maxRetries; attempt++) {
      try {
        const response = await fetch('/api/parse-invoice', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(bodyData),
        });

        if (response.status === 429 || response.status === 503) {
          if (attempt === maxRetries - 1) {
            throw new Error(`Failed with status ${response.status} after ${maxRetries} attempts.`);
          }
          console.warn(`Attempt ${attempt + 1} got ${response.status} status. Retrying in ${delayMs}ms...`);
          await new Promise(resolve => setTimeout(resolve, delayMs));
          continue;
        }

        if (!response.ok) {
          const errJson = await response.json();
          const errText = String(errJson.error || '').toLowerCase();
          const isRetryable = errText.includes('quota') || 
                              errText.includes('429') || 
                              errText.includes('rate') || 
                              errText.includes('exhausted') ||
                              errText.includes('503') ||
                              errText.includes('overloaded') ||
                              errText.includes('service unavailable');

          if (isRetryable && attempt < maxRetries - 1) {
            console.warn(`Attempt ${attempt + 1} got retryable error inside response body. Retrying in ${delayMs}ms...`);
            await new Promise(resolve => setTimeout(resolve, delayMs));
            continue;
          }
          throw new Error(errJson.error || 'Server parsing failed');
        }

        return await response.json();
      } catch (err: any) {
        lastError = err;
        const errStr = String(err.message || err).toLowerCase();
        const isRetryableErr = errStr.includes('429') || 
                               errStr.includes('quota') || 
                               errStr.includes('rate') || 
                               errStr.includes('exhausted') ||
                               errStr.includes('503') ||
                               errStr.includes('overloaded') ||
                               errStr.includes('service unavailable');

        if (isRetryableErr && attempt < maxRetries - 1) {
          console.warn(`Attempt ${attempt + 1} caught retryable error: ${err.message}. Retrying in ${delayMs}ms...`);
          await new Promise(resolve => setTimeout(resolve, delayMs));
          continue;
        }
        throw err;
      }
    }
    throw lastError || new Error('Max retries exceeded');
  };

  // Parse invoice with server-side Gemini or Excel parser
  const parseInvoiceWithGemini = async (selectedFile: File) => {
    setIsParsing(true);
    setParseError(null);
    try {
      const ext = selectedFile.name.split('.').pop()?.toLowerCase() || '';
      let parsed: any = null;

      if (['xlsx', 'xls', 'csv'].includes(ext)) {
        const arrayBuffer = await selectedFile.arrayBuffer();
        const { items, csvText } = parseExcelInvoiceData(arrayBuffer);

        if (items.length > 1) {
          // If the Excel spreadsheet contains multiple invoices, automatically run batch matching on all rows!
          const batchRes: BatchItem[] = [];
          for (let i = 0; i < items.length; i++) {
            const item = items[i];
            const matchRes = performMatching({
              Invoice_Number: item.invoiceNumber || `INV-${i + 1}`,
              Supplier: item.supplier || 'Unknown Supplier',
              Quantity_Invoiced: item.quantityInvoiced,
              Unit_Price: item.unitPrice,
              Invoice_Amount: item.invoiceAmount,
              PO_Number: item.poNumber,
              Date_Processed: new Date().toISOString().split('T')[0]
            }, db);

            batchRes.push({
              filename: `${selectedFile.name} (Row ${i + 1})`,
              invoiceNumber: item.invoiceNumber || `INV-${i + 1}`,
              supplier: item.supplier || 'Unknown Supplier',
              poNumber: item.poNumber,
              quantityInvoiced: item.quantityInvoiced,
              unitPrice: item.unitPrice,
              invoiceAmount: item.invoiceAmount,
              status: matchRes.status,
              reason: matchRes.status === 'Cleared' ? 'Fully verified with PO and GRN.' : matchRes.explanation,
              textContent: csvText,
            });
          }

          const first = items[0];
          setInvoiceNumber(first.invoiceNumber || '');
          setSupplier(first.supplier || '');
          setPoNumber(first.poNumber ? normalizePONumber(first.poNumber) : '');
          setQuantityInvoiced(first.quantityInvoiced || '');
          setUnitPrice(first.unitPrice || '');
          setInvoiceAmount(first.invoiceAmount || '');

          setBatchItems(batchRes);
          setActionSuccess(`Excel Sheet Parsed! Found ${items.length} invoice records. First item loaded into verification form, and full batch list populated below.`);
          return;
        } else if (items.length === 1 && (items[0].invoiceNumber || items[0].supplier || items[0].poNumber)) {
          parsed = items[0];
        } else {
          // Layout sheet or unrecognized columns, use Gemini text content parsing
          parsed = await parseInvoiceWithRetry({ textContent: csvText });
        }
      } else {
        const base64Data = await fileToBase64(selectedFile);
        const mimeType = selectedFile.type || (ext === 'pdf' ? 'application/pdf' : 'image/jpeg');
        parsed = await parseInvoiceWithRetry({ base64Data, mimeType });
      }

      // Populate form fields
      setInvoiceNumber(parsed.invoiceNumber || '');
      setSupplier(parsed.supplier || '');
      setPoNumber(parsed.poNumber ? normalizePONumber(parsed.poNumber) : '');
      setQuantityInvoiced(parsed.quantityInvoiced ? parseInt(parsed.quantityInvoiced) : '');
      setUnitPrice(parsed.unitPrice ? parseFloat(parsed.unitPrice) : '');
      setInvoiceAmount(parsed.invoiceAmount ? parseFloat(parsed.invoiceAmount) : '');

      setActionSuccess('Excellent! Invoice successfully analyzed and fields populated below for your review.');
    } catch (err: any) {
      console.error(err);
      setParseError(err.message || 'Failed to analyze invoice document. You can still input details manually below.');
    } finally {
      setIsParsing(false);
    }
  };

  const handleXlsxUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setSheetError(null);
    setActionSuccess(null);
    try {
      const data = await file.arrayBuffer();
      const workbook = XLSX.read(data, { type: 'array' });
      
      let poSheetName = '';
      let grnSheetName = '';
      
      for (const name of workbook.SheetNames) {
        const lower = name.toLowerCase();
        if (lower.includes('purchase') || lower.includes('po')) {
          poSheetName = name;
        } else if (lower.includes('goods') || lower.includes('received') || lower.includes('grn')) {
          grnSheetName = name;
        }
      }
      
      if (!poSheetName) {
        throw new Error('Could not find a sheet for Purchase Orders (POs) in the Excel file.');
      }
      if (!grnSheetName) {
        throw new Error('Could not find a sheet for Goods Received Notes (GRNs) in the Excel file.');
      }
      
      const poSheet = workbook.Sheets[poSheetName];
      const grnSheet = workbook.Sheets[grnSheetName];
      
      const poRowsRaw = XLSX.utils.sheet_to_json<any>(poSheet);
      const grnRowsRaw = XLSX.utils.sheet_to_json<any>(grnSheet);
      
      const normalizeKey = (s: string) => s.toLowerCase().replace(/[\s_\-$()]/g, '');

      const getVal = (row: any, keys: string[]) => {
        const normalizedSearchKeys = keys.map(k => normalizeKey(k));
        const rowKeys = Object.keys(row);
        
        for (const nk of normalizedSearchKeys) {
          const foundKey = rowKeys.find(rk => normalizeKey(rk) === nk);
          if (foundKey !== undefined) {
            return row[foundKey];
          }
        }
        return undefined;
      };

      const parsePO = (row: any): PurchaseOrder => {
        return {
          PO_Number: String(getVal(row, ['po_number', 'ponumber', 'po']) || '').trim(),
          Supplier: String(getVal(row, ['supplier_name', 'suppliername', 'supplier', 'vendor']) || '').trim(),
          Item: String(getVal(row, ['item_description', 'itemdescription', 'item', 'description']) || '').trim(),
          Quantity_Ordered: Number(getVal(row, ['qty_ordered', 'qtyordered', 'quantity_ordered', 'quantityordered', 'quantity', 'qty']) || 0),
          Unit_Price: Number(getVal(row, ['unit_price', 'unitprice', 'price', 'rate']) || 0)
        };
      };
      
      const parseGRN = (row: any): GoodsReceivedNote => {
        return {
          GRN_Number: String(getVal(row, ['grn_number', 'grnnumber', 'grn', 'receipt_number']) || '').trim(),
          PO_Number: String(getVal(row, ['po_number', 'ponumber', 'po']) || '').trim(),
          Quantity_Received: Number(getVal(row, ['qty_received', 'qtyreceived', 'quantity_received', 'quantityreceived', 'received_qty', 'received', 'quantity']) || 0),
          Date_Received: String(getVal(row, ['grn_date', 'grndate', 'date_received', 'datereceived', 'received_date', 'date']) || '').trim()
        };
      };
      
      const purchaseOrders = poRowsRaw.map(parsePO).filter(p => p.PO_Number);
      const goodsReceivedNotes = grnRowsRaw.map(parseGRN).filter(g => g.GRN_Number && g.PO_Number);
      
      const newDb: DatabaseState = {
        purchaseOrders,
        goodsReceivedNotes,
        processedInvoices: db.processedInvoices
      };
      
      saveLocalDb(newDb);
      setIsLocalMode(true);
      setConnectedSheetId(null);
      localStorage.removeItem('ap_connected_sheet_id');
      
      let samplePoInfo = '';
      if (purchaseOrders.length > 0) {
        const firstPo = purchaseOrders[0];
        samplePoInfo = ` (e.g. ${firstPo.PO_Number}: ${firstPo.Supplier}, ${firstPo.Quantity_Ordered} units @ $${Number(firstPo.Unit_Price).toFixed(2)})`;
      }
      
      setActionSuccess(`Loaded ${purchaseOrders.length} POs${samplePoInfo} and ${goodsReceivedNotes.length} GRNs from ${file.name}`);
    } catch (err: any) {
      console.error('Error loading XLSX database:', err);
      setSheetError(`Failed to load Excel file: ${err.message || err}`);
    }
  };

  const handleExportThreeWayMatched = async () => {
    const matchedInvoices = db.processedInvoices.filter(
      i => i.MatchStatus === 'Cleared'
    );

    if (matchedInvoices.length === 0) {
      setSheetError('No 3-way matched (Cleared) invoices available to export. Please verify or approve pending invoices first.');
      return;
    }

    const targetSheetId = connectedSheetId || DEFAULT_SPREADSHEET_ID;

    let currentToken = token;
    if (!currentToken) {
      try {
        const result = await signInWithPopup(auth, provider);
        const credential = GoogleAuthProvider.credentialFromResult(result);
        if (credential?.accessToken) {
          currentToken = credential.accessToken;
          setToken(currentToken);
          setUser(result.user);
          setIsLocalMode(false);
        } else {
          throw new Error('Google authentication required to write to Google Sheets.');
        }
      } catch (err: any) {
        setSheetError(`Authentication required to write to Google Sheets: ${err.message || err}`);
        return;
      }
    }

    setIsExporting(true);
    setSheetError(null);
    setActionSuccess(null);

    try {
      const tabName = 'Three Way Matched';

      // 1. Get spreadsheet metadata to check if "Three Way Matched" tab exists
      const metaRes = await fetch(`https://sheets.googleapis.com/v4/spreadsheets/${targetSheetId}`, {
        headers: { Authorization: `Bearer ${currentToken}` }
      });

      if (!metaRes.ok) {
        const errJson = await metaRes.json();
        throw new Error(errJson.error?.message || 'Failed to access Google Sheet.');
      }

      const meta = await metaRes.json();
      const sheetTitles: string[] = meta.sheets?.map((s: any) => s.properties?.title) || [];

      // Create tab if missing
      if (!sheetTitles.includes(tabName)) {
        const addSheetRes = await fetch(`https://sheets.googleapis.com/v4/spreadsheets/${targetSheetId}:batchUpdate`, {
          method: 'POST',
          headers: {
            Authorization: `Bearer ${currentToken}`,
            'Content-Type': 'application/json'
          },
          body: JSON.stringify({
            requests: [
              {
                addSheet: {
                  properties: {
                    title: tabName
                  }
                }
              }
            ]
          })
        });

        if (!addSheetRes.ok) {
          const errJson = await addSheetRes.json();
          throw new Error(errJson.error?.message || 'Could not create "Three Way Matched" worksheet tab in Google Sheet.');
        }
      }

      // 2. Format row values
      const headers = [
        'Invoice Number',
        'Supplier',
        'PO Number',
        'Invoice Amount ($)',
        'Quantity Invoiced',
        'Unit Price ($)',
        'Date Processed',
        'Match Status',
        'Explanation',
        'Follow Up Action'
      ];

      const rows = matchedInvoices.map(inv => [
        inv.Invoice_Number,
        inv.Supplier,
        inv.PO_Number,
        inv.Invoice_Amount,
        inv.Quantity_Invoiced,
        inv.Unit_Price,
        inv.Date_Processed,
        inv.MatchStatus,
        inv.Explanation || 'Verified 3-Way Match (Invoice matches PO and GRN)',
        inv.FollowUpAction || 'Cleared for Payment'
      ]);

      const values = [headers, ...rows];

      // 3. Clear existing values in "Three Way Matched" tab
      await fetch(
        `https://sheets.googleapis.com/v4/spreadsheets/${targetSheetId}/values/${encodeURIComponent(`'${tabName}'!A1:Z1000`)}:clear`,
        {
          method: 'POST',
          headers: { Authorization: `Bearer ${currentToken}` }
        }
      );

      // 4. Write values to "Three Way Matched" tab
      const writeRes = await fetch(
        `https://sheets.googleapis.com/v4/spreadsheets/${targetSheetId}/values/${encodeURIComponent(`'${tabName}'!A1`)}?valueInputOption=USER_ENTERED`,
        {
          method: 'PUT',
          headers: {
            Authorization: `Bearer ${currentToken}`,
            'Content-Type': 'application/json'
          },
          body: JSON.stringify({
            range: `'${tabName}'!A1`,
            majorDimension: 'ROWS',
            values: values
          })
        }
      );

      if (!writeRes.ok) {
        const errJson = await writeRes.json();
        throw new Error(errJson.error?.message || 'Failed to update Google Sheet tab.');
      }

      setActionSuccess(`Successfully exported ${matchedInvoices.length} 3-Way Matched item(s) to worksheet tab "${tabName}" in Google Sheet!`);
    } catch (err: any) {
      console.error('Export Error:', err);
      setSheetError(`Failed to export to Google Sheet: ${err.message || err}`);
    } finally {
      setIsExporting(false);
    }
  };

  const handleScanAPInvoices = async () => {
    setSheetError(null);
    setActionSuccess(null);

    let currentToken = token;
    if (!currentToken) {
      try {
        const result = await signInWithPopup(auth, provider);
        const credential = GoogleAuthProvider.credentialFromResult(result);
        if (credential?.accessToken) {
          currentToken = credential.accessToken;
          setToken(currentToken);
          setUser(result.user);
          setIsLocalMode(false);
        } else {
          throw new Error('Google authentication required to scan Google Sheet AP Invoices tab.');
        }
      } catch (err: any) {
        setSheetError(`Authentication required to scan Google Sheet: ${err.message || err}`);
        return;
      }
    }

    if (currentToken) {
      setIsSheetLoading(true);
      try {
        const targetSheetId = connectedSheetId || DEFAULT_SPREADSHEET_ID;
        await loadSheetData(targetSheetId, currentToken, false);
        setActionSuccess('Successfully scanned "AP Invoices" sheet for changes! Cross-referenced all items against Purchase Orders and Goods Receipts.');
      } catch (err: any) {
        console.error(err);
        setSheetError(`Failed to scan "AP Invoices" sheet tab: ${err.message || err}`);
      } finally {
        setIsSheetLoading(false);
      }
    }
  };

  // Manual single invoice approval
  const handleApproveInvoice = (invoiceToApprove: ProcessedInvoice) => {
    const updatedInvoices = db.processedInvoices.map((inv) => {
      if (
        inv.Invoice_Number.trim().toLowerCase() === invoiceToApprove.Invoice_Number.trim().toLowerCase() &&
        inv.Supplier.trim().toLowerCase() === invoiceToApprove.Supplier.trim().toLowerCase()
      ) {
        return {
          ...inv,
          MatchStatus: 'Cleared' as const,
          Explanation: inv.Explanation?.includes('Manually Approved')
            ? inv.Explanation
            : `Manually Approved: ${inv.Explanation || 'Verified and approved by AP manager.'}`,
          FollowUpAction: 'Approved by AP Administrator. Proceed to payment dispatch.',
          ApprovedAt: new Date().toISOString()
        };
      }
      return inv;
    });

    saveLocalDb({ ...db, processedInvoices: updatedInvoices });
    setActionSuccess(`Invoice #${invoiceToApprove.Invoice_Number} from ${invoiceToApprove.Supplier} has been manually APPROVED.`);
  };

  // Manual single invoice denial
  const handleDenyInvoice = (invoiceToDeny: ProcessedInvoice) => {
    const updatedInvoices = db.processedInvoices.map((inv) => {
      if (
        inv.Invoice_Number.trim().toLowerCase() === invoiceToDeny.Invoice_Number.trim().toLowerCase() &&
        inv.Supplier.trim().toLowerCase() === invoiceToDeny.Supplier.trim().toLowerCase()
      ) {
        return {
          ...inv,
          MatchStatus: 'Flagged' as const,
          Explanation: inv.Explanation?.includes('Manually Denied')
            ? inv.Explanation
            : `Manually Denied: ${inv.Explanation || 'Denied by AP manager.'}`,
          FollowUpAction: 'Invoice rejected by AP Administrator upon manual review.',
        };
      }
      return inv;
    });

    saveLocalDb({ ...db, processedInvoices: updatedInvoices });
    setActionSuccess(`Invoice #${invoiceToDeny.Invoice_Number} from ${invoiceToDeny.Supplier} has been manually DENIED / FLAGGED.`);
  };

  // Batch approve all invoices that successfully match PO & GRN 3-Way criteria
  const handleBatchApproveMatched = () => {
    let approvedCount = 0;
    const updatedInvoices = db.processedInvoices.map((inv) => {
      const matchRes = performMatching(inv, {
        purchaseOrders: db.purchaseOrders,
        goodsReceivedNotes: db.goodsReceivedNotes,
        processedInvoices: []
      });

      if (matchRes.status === 'Cleared' && inv.MatchStatus !== 'Cleared') {
        approvedCount++;
        return {
          ...inv,
          MatchStatus: 'Cleared' as const,
          Explanation: `Cleared: Verified 3-way match with PO (${inv.PO_Number}) and GRN records.`,
          FollowUpAction: 'Batch approved by AP Administrator. Payment is cleared.',
          ApprovedAt: new Date().toISOString()
        };
      }
      return inv;
    });

    if (approvedCount === 0) {
      setActionSuccess('All 3-way matched invoices are already approved or no additional pending/flagged invoices currently meet the 3-way match requirements.');
      return;
    }

    saveLocalDb({ ...db, processedInvoices: updatedInvoices });
    setActionSuccess(`Batch Approval Successful! Approved ${approvedCount} invoice(s) that verified against PO & GRN records.`);
  };

  const handleBatchZipUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setSheetError(null);
    setActionSuccess(null);
    setBatchItems([]);
    setBatchProgressTitle('Processing ZIP Archive...');
    setIsProcessingBatch(true);
    setConsecutive429s(0);

    try {
      const zip = new JSZip();
      const contents = await zip.loadAsync(file);
      
      const fileEntries = Object.keys(contents.files).filter(filename => {
        const isDir = contents.files[filename].dir;
        const ext = filename.split('.').pop()?.toLowerCase();
        return !isDir && ext && ['pdf', 'jpeg', 'jpg', 'png', 'xlsx', 'xls', 'csv'].includes(ext);
      });

      if (fileEntries.length === 0) {
        throw new Error('No valid PDF, Image (JPG/PNG), Excel (.xlsx/.xls), or CSV files found in the ZIP archive.');
      }

      setBatchProgress({ current: 0, total: fileEntries.length });
      const results: BatchItem[] = [];

      for (let i = 0; i < fileEntries.length; i++) {
        const filename = fileEntries[i];
        setBatchProgress({ current: i + 1, total: fileEntries.length });

        let currentBase64 = '';
        let currentMimeType = 'application/pdf';

        try {
          const ext = filename.split('.').pop()?.toLowerCase() || '';

          if (['xlsx', 'xls', 'csv'].includes(ext)) {
            const zipFile = contents.files[filename];
            const arrayBuffer = await zipFile.async('arraybuffer');
            const { items, csvText } = parseExcelInvoiceData(arrayBuffer);

            let parsedList = items;
            if (parsedList.length === 0) {
              const aiParsed = await parseInvoiceWithRetry({ textContent: csvText });
              parsedList = [aiParsed];
            }

            for (let j = 0; j < parsedList.length; j++) {
              const parsed = parsedList[j];
              const invNumber = parsed.invoiceNumber || 'Unknown';
              const supp = parsed.supplier || 'Unknown';
              const poNo = parsed.poNumber ? normalizePONumber(parsed.poNumber) : 'Unknown';
              const qty = parsed.quantityInvoiced ? parseInt(String(parsed.quantityInvoiced)) : 0;
              const price = parsed.unitPrice ? parseFloat(String(parsed.unitPrice)) : 0;
              const amt = parsed.invoiceAmount ? parseFloat(String(parsed.invoiceAmount)) : 0;

              const matchRes = performMatching({
                Invoice_Number: invNumber,
                Supplier: supp,
                Invoice_Amount: amt,
                Quantity_Invoiced: qty,
                Unit_Price: price,
                PO_Number: poNo,
                Date_Processed: new Date().toISOString().split('T')[0]
              }, db);

              results.push({
                filename: parsedList.length > 1 ? `${filename} (Row ${j + 1})` : filename,
                invoiceNumber: invNumber,
                supplier: supp,
                poNumber: poNo,
                invoiceAmount: amt,
                quantityInvoiced: qty,
                unitPrice: price,
                status: matchRes.status,
                reason: matchRes.status === 'Cleared' ? 'Fully verified with PO and GRN.' : matchRes.explanation,
                textContent: csvText
              });
            }
            continue;
          }

          currentBase64 = '';
          currentMimeType = 'application/pdf';

          // Introduce pacing delay to avoid hitting rate limits aggressively (5.5 seconds)
          if (i > 0) {
            await new Promise(resolve => setTimeout(resolve, 5500));
          }

          const zipFile = contents.files[filename];
          const blob = await zipFile.async('blob');
          
          if (ext === 'jpg' || ext === 'jpeg') currentMimeType = 'image/jpeg';
          else if (ext === 'png') currentMimeType = 'image/png';

          currentBase64 = await new Promise<string>((resolve, reject) => {
            const reader = new FileReader();
            reader.readAsDataURL(blob);
            reader.onload = () => {
              const base64String = (reader.result as string).split(',')[1];
              resolve(base64String);
            };
            reader.onerror = reject;
          });

          const parsed = await parseInvoiceWithRetry(currentBase64, currentMimeType);
          setConsecutive429s(0); // Reset on successful API call

          const invNumber = parsed.invoiceNumber || 'Unknown';
          const supp = parsed.supplier || 'Unknown';
          const poNo = parsed.poNumber ? normalizePONumber(parsed.poNumber) : 'Unknown';
          const qty = parsed.quantityInvoiced ? parseInt(parsed.quantityInvoiced) : 0;
          const price = parsed.unitPrice ? parseFloat(parsed.unitPrice) : 0;
          const amt = parsed.invoiceAmount ? parseFloat(parsed.invoiceAmount) : 0;

          const matchRes = performMatching({
            Invoice_Number: invNumber,
            Supplier: supp,
            Invoice_Amount: amt,
            Quantity_Invoiced: qty,
            Unit_Price: price,
            PO_Number: poNo,
            Date_Processed: new Date().toISOString().split('T')[0]
          }, db);

          results.push({
            filename,
            invoiceNumber: invNumber,
            supplier: supp,
            poNumber: poNo,
            invoiceAmount: amt,
            quantityInvoiced: qty,
            unitPrice: price,
            status: matchRes.status,
            reason: matchRes.status === 'Cleared' ? 'Fully verified with PO and GRN.' : matchRes.explanation,
            base64Data: currentBase64,
            mimeType: currentMimeType
          });

        } catch (itemErr: any) {
          console.error(`Error processing batch file ${filename}:`, itemErr);
          const errMsg = String(itemErr.message || itemErr);
          const is429 = errMsg.includes('429') || errMsg.toLowerCase().includes('quota') || errMsg.toLowerCase().includes('rate') || errMsg.toLowerCase().includes('exhausted');
          
          if (is429) {
            setConsecutive429s(prev => prev + 1);
          } else {
            setConsecutive429s(0);
          }

          results.push({
            filename,
            invoiceNumber: 'Failed',
            supplier: 'Failed',
            poNumber: 'Failed',
            invoiceAmount: 0,
            quantityInvoiced: 0,
            unitPrice: 0,
            status: 'Failed',
            reason: `Error: ${itemErr.message || itemErr}`,
            base64Data: currentBase64,
            mimeType: currentMimeType
          });
        }

        setBatchItems([...results]);
      }

      setActionSuccess(`Batch verification completed. Successfully processed ${fileEntries.length} invoices.`);
    } catch (err: any) {
      console.error('Error loading ZIP:', err);
      setSheetError(`Failed to process ZIP: ${err.message || err}`);
    } finally {
      setIsProcessingBatch(false);
    }
  };

  const handleRetryFailedBatch = async () => {
    const failedItemsIdxs = batchItems
      .map((item, idx) => ({ item, idx }))
      .filter(({ item }) => item.status === 'Failed');

    if (failedItemsIdxs.length === 0) return;

    setSheetError(null);
    setActionSuccess(null);
    setBatchProgressTitle('Retrying Failed Invoices...');
    setIsProcessingBatch(true);
    setConsecutive429s(0);
    setBatchProgress({ current: 0, total: failedItemsIdxs.length });

    // Create a copy of batchItems to mutate in state
    const updatedItems = [...batchItems];

    try {
      for (let i = 0; i < failedItemsIdxs.length; i++) {
        const { item, idx } = failedItemsIdxs[i];
        setBatchProgress({ current: i + 1, total: failedItemsIdxs.length });

        // Introduce pacing delay between API calls (5.5 seconds)
        if (i > 0) {
          await new Promise(resolve => setTimeout(resolve, 5500));
        }

        try {
          if (!item.base64Data) {
            throw new Error('No cached base64 data available for this file.');
          }

          const parsed = await parseInvoiceWithRetry(item.base64Data, item.mimeType || 'application/pdf');
          setConsecutive429s(0); // Reset on successful API call

          const invNumber = parsed.invoiceNumber || 'Unknown';
          const supp = parsed.supplier || 'Unknown';
          const poNo = parsed.poNumber ? normalizePONumber(parsed.poNumber) : 'Unknown';
          const qty = parsed.quantityInvoiced ? parseInt(parsed.quantityInvoiced) : 0;
          const price = parsed.unitPrice ? parseFloat(parsed.unitPrice) : 0;
          const amt = parsed.invoiceAmount ? parseFloat(parsed.invoiceAmount) : 0;

          const matchRes = performMatching({
            Invoice_Number: invNumber,
            Supplier: supp,
            Invoice_Amount: amt,
            Quantity_Invoiced: qty,
            Unit_Price: price,
            PO_Number: poNo,
            Date_Processed: new Date().toISOString().split('T')[0]
          }, db);

          updatedItems[idx] = {
            ...item,
            invoiceNumber: invNumber,
            supplier: supp,
            poNumber: poNo,
            invoiceAmount: amt,
            quantityInvoiced: qty,
            unitPrice: price,
            status: matchRes.status,
            reason: matchRes.status === 'Cleared' ? 'Fully verified with PO and GRN.' : matchRes.explanation
          };

        } catch (itemErr: any) {
          console.error(`Error retrying batch file ${item.filename}:`, itemErr);
          const errMsg = String(itemErr.message || itemErr);
          const is429 = errMsg.includes('429') || errMsg.toLowerCase().includes('quota') || errMsg.toLowerCase().includes('rate') || errMsg.toLowerCase().includes('exhausted');
          
          if (is429) {
            setConsecutive429s(prev => prev + 1);
          } else {
            setConsecutive429s(0);
          }

          updatedItems[idx] = {
            ...item,
            status: 'Failed',
            reason: `Error: ${itemErr.message || itemErr}`
          };
        }

        setBatchItems([...updatedItems]);
      }

      const totalSucceeded = failedItemsIdxs.filter(({ idx }) => updatedItems[idx].status !== 'Failed').length;
      setActionSuccess(`Batch retry completed. Successfully re-processed ${totalSucceeded} of ${failedItemsIdxs.length} failed invoices.`);
    } catch (err: any) {
      console.error('Error retrying failed batch items:', err);
      setSheetError(`Failed to complete retry: ${err.message || err}`);
    } finally {
      setIsProcessingBatch(false);
    }
  };

  const handleLogIndividualBatchItem = async (item: BatchItem) => {
    const isAlreadyLogged = db.processedInvoices.some(
      (pi) =>
        pi.Invoice_Number.trim().toLowerCase() === item.invoiceNumber.trim().toLowerCase() &&
        pi.Supplier.trim().toLowerCase() === item.supplier.trim().toLowerCase()
    );
    if (isAlreadyLogged) {
      alert(`Invoice #${item.invoiceNumber} from ${item.supplier} is already logged.`);
      return;
    }

    const newRecord: ProcessedInvoice = {
      Invoice_Number: item.invoiceNumber,
      Supplier: item.supplier,
      Invoice_Amount: item.invoiceAmount,
      Quantity_Invoiced: item.quantityInvoiced,
      Unit_Price: item.unitPrice,
      PO_Number: item.poNumber,
      Date_Processed: new Date().toISOString().split('T')[0],
      MatchStatus: item.status === 'Cleared' ? 'Cleared' : 'Flagged',
      Explanation: item.reason,
      FollowUpAction: item.status === 'Cleared' 
        ? 'No follow up needed. Payment is approved.' 
        : 'Please follow up with purchasing or warehouse to resolve mismatches.',
      ApprovedAt: new Date().toISOString()
    };

    if (isLocalMode) {
      const updatedInvoices = [newRecord, ...db.processedInvoices];
      saveLocalDb({ ...db, processedInvoices: updatedInvoices });
      setActionSuccess(`Successfully logged invoice #${item.invoiceNumber} locally.`);
    } else {
      if (!token || !connectedSheetId) {
        alert('Authentication lost. Please sign in again.');
        return;
      }
      setIsSheetLoading(true);
      try {
        const appendRes = await fetch(`https://sheets.googleapis.com/v4/spreadsheets/${connectedSheetId}/values/Processed%20Invoices!A:J:append?valueInputOption=USER_ENTERED`, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            Authorization: `Bearer ${token}`,
          },
          body: JSON.stringify({
            range: 'Processed Invoices!A:J',
            majorDimension: 'ROWS',
            values: [
              [
                newRecord.Invoice_Number,
                newRecord.Supplier,
                newRecord.Invoice_Amount,
                newRecord.Quantity_Invoiced,
                newRecord.Unit_Price,
                newRecord.PO_Number,
                newRecord.Date_Processed,
                newRecord.MatchStatus,
                newRecord.Explanation,
                newRecord.FollowUpAction
              ]
            ]
          }),
        });

        if (!appendRes.ok) {
          throw new Error('Failed to save to Google Sheet.');
        }

        await loadSheetData(connectedSheetId, token);
        setActionSuccess(`Successfully logged invoice #${item.invoiceNumber} to Google Sheets.`);
      } catch (err: any) {
        console.error('Error logging to Google Sheets:', err);
        alert(`Failed to save to Google Sheets: ${err.message || err}. Logged locally instead.`);
        const updatedInvoices = [newRecord, ...db.processedInvoices];
        saveLocalDb({ ...db, processedInvoices: updatedInvoices });
      } finally {
        setIsSheetLoading(false);
      }
    }
  };

  const handleLogAllClearedBatch = async () => {
    const cleared = batchItems.filter(b => b.status === 'Cleared');
    if (cleared.length === 0) return;

    const loggedRecords: ProcessedInvoice[] = [];

    for (const item of cleared) {
      const isAlreadyLogged = db.processedInvoices.some(
        (pi) =>
          pi.Invoice_Number.trim().toLowerCase() === item.invoiceNumber.trim().toLowerCase() &&
          pi.Supplier.trim().toLowerCase() === item.supplier.trim().toLowerCase()
      );
      if (isAlreadyLogged) {
        continue;
      }

      loggedRecords.push({
        Invoice_Number: item.invoiceNumber,
        Supplier: item.supplier,
        Invoice_Amount: item.invoiceAmount,
        Quantity_Invoiced: item.quantityInvoiced,
        Unit_Price: item.unitPrice,
        PO_Number: item.poNumber,
        Date_Processed: new Date().toISOString().split('T')[0],
        MatchStatus: 'Cleared',
        Explanation: item.reason,
        FollowUpAction: 'No follow up needed. Payment is approved.',
        ApprovedAt: new Date().toISOString()
      });
    }

    if (loggedRecords.length === 0) {
      alert('All cleared invoices are already logged.');
      return;
    }

    if (isLocalMode) {
      const updatedInvoices = [...loggedRecords, ...db.processedInvoices];
      saveLocalDb({ ...db, processedInvoices: updatedInvoices });
      setActionSuccess(`Successfully logged ${loggedRecords.length} cleared invoices locally.`);
    } else {
      if (!token || !connectedSheetId) {
        alert('Authentication lost. Please sign in again.');
        return;
      }
      setIsSheetLoading(true);
      try {
        const rowsToAppend = loggedRecords.map(record => [
          record.Invoice_Number,
          record.Supplier,
          record.Invoice_Amount,
          record.Quantity_Invoiced,
          record.Unit_Price,
          record.PO_Number,
          record.Date_Processed,
          record.MatchStatus,
          record.Explanation,
          record.FollowUpAction
        ]);

        const appendRes = await fetch(`https://sheets.googleapis.com/v4/spreadsheets/${connectedSheetId}/values/Processed%20Invoices!A:J:append?valueInputOption=USER_ENTERED`, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            Authorization: `Bearer ${token}`,
          },
          body: JSON.stringify({
            range: 'Processed Invoices!A:J',
            majorDimension: 'ROWS',
            values: rowsToAppend
          }),
        });

        if (!appendRes.ok) {
          throw new Error('Failed to save to Google Sheet.');
        }

        await loadSheetData(connectedSheetId, token);
        setActionSuccess(`Successfully logged ${loggedRecords.length} cleared invoices to Google Sheets.`);
      } catch (err: any) {
        console.error('Error logging to Google Sheets:', err);
        alert(`Failed to save to Google Sheets: ${err.message || err}. Logged locally instead.`);
        const updatedInvoices = [...loggedRecords, ...db.processedInvoices];
        saveLocalDb({ ...db, processedInvoices: updatedInvoices });
      } finally {
        setIsSheetLoading(false);
      }
    }
  };

  // Run 3-Way Match and Duplicate Checks
  const handleVerifyInvoice = () => {
    if (!invoiceNumber || !supplier || !invoiceAmount || !quantityInvoiced || !unitPrice || !poNumber) {
      alert('Please fill in all invoice fields first.');
      return;
    }

    setIsMatchingLoading(true);
    setTimeout(() => {
      const result = performMatching({
        Invoice_Number: invoiceNumber,
        Supplier: supplier,
        Invoice_Amount: Number(invoiceAmount),
        Quantity_Invoiced: Number(quantityInvoiced),
        Unit_Price: Number(unitPrice),
        PO_Number: poNumber,
        Date_Processed: new Date().toISOString().split('T')[0]
      }, db);

      setMatchingResult(result);
      setHasChecked(true);
      setIsMatchingLoading(false);
    }, 600); // short aesthetic delay for realistic analysis feel
  };

  // Confirm and Send to Payment List (Manual Step)
  const handleConfirmAndSend = () => {
    if (!matchingResult) return;

    setConfirmModal({
      isOpen: true,
      title: 'Log Processed Invoice?',
      message: `Confirm Invoice #${invoiceNumber} from ${supplier} and add to the processed payment log?`,
      onConfirm: async () => {
        setConfirmModal(null);
        const newInvoiceRecord: ProcessedInvoice = {
          Invoice_Number: invoiceNumber,
          Supplier: supplier,
          Invoice_Amount: Number(invoiceAmount),
          Quantity_Invoiced: Number(quantityInvoiced),
          Unit_Price: Number(unitPrice),
          PO_Number: poNumber,
          Date_Processed: new Date().toISOString().split('T')[0],
          MatchStatus: matchingResult.status,
          Explanation: matchingResult.explanation,
          FollowUpAction: matchingResult.followUp,
          ApprovedAt: new Date().toISOString()
        };

        if (isLocalMode) {
          // Local Mode: Save to local storage
          const updatedInvoices = [newInvoiceRecord, ...db.processedInvoices];
          saveLocalDb({ ...db, processedInvoices: updatedInvoices });
          finalizeSuccess();
        } else {
          // Sheets Mode: Append row directly to connected Google Sheet
          if (!token || !connectedSheetId) {
            alert('Authentication lost. Please sign in again.');
            return;
          }
          setIsSheetLoading(true);
          try {
            const appendRes = await fetch(`https://sheets.googleapis.com/v4/spreadsheets/${connectedSheetId}/values/Processed%20Invoices!A:J:append?valueInputOption=USER_ENTERED`, {
              method: 'POST',
              headers: {
                'Content-Type': 'application/json',
                Authorization: `Bearer ${token}`,
              },
              body: JSON.stringify({
                range: 'Processed Invoices!A:J',
                majorDimension: 'ROWS',
                values: [
                  [
                    newInvoiceRecord.Invoice_Number,
                    newInvoiceRecord.Supplier,
                    newInvoiceRecord.Invoice_Amount,
                    newInvoiceRecord.Quantity_Invoiced,
                    newInvoiceRecord.Unit_Price,
                    newInvoiceRecord.PO_Number,
                    newInvoiceRecord.Date_Processed,
                    newInvoiceRecord.MatchStatus,
                    newInvoiceRecord.Explanation,
                    newInvoiceRecord.FollowUpAction
                  ]
                ]
              }),
            });

            if (!appendRes.ok) {
              throw new Error('Failed to save to Google Sheet.');
            }

            // Reload data to stay perfectly in sync
            await loadSheetData(connectedSheetId, token);
            finalizeSuccess();
          } catch (err: any) {
            console.error(err);
            alert(`Failed to save invoice to Google Sheets: ${err.message || err}`);
          } finally {
            setIsSheetLoading(false);
          }
        }
      }
    });
  };

  const finalizeSuccess = () => {
    setActionSuccess(`Successfully sent Invoice #${invoiceNumber} to the payment log!`);
    
    // Clear submission form
    setInvoiceNumber('');
    setSupplier('');
    setPoNumber('');
    setQuantityInvoiced('');
    setUnitPrice('');
    setInvoiceAmount('');
    setFile(null);
    setFilePreview(null);
    setHasChecked(false);
    setMatchingResult(null);

    // Focus on log tab to review entry
    setActiveTab('invoices');
  };

  // Dashboard Stats calculation
  const todayStr = new Date().toISOString().split('T')[0];
  const invoicesProcessedToday = db.processedInvoices.filter(i => i.Date_Processed === todayStr);
  const totalProcessedCount = db.processedInvoices.length;
  
  // Pending Count (Invoices awaiting 3-way verification)
  const pendingInvoices = db.processedInvoices.filter(i => i.MatchStatus === 'Pending');
  const pendingCount = pendingInvoices.length;
  const pendingTotalAmount = pendingInvoices.reduce((sum, i) => sum + (i.Invoice_Amount || 0), 0);

  // Cleared Count (Total cleared ready for payment in the database)
  const clearedCount = db.processedInvoices.filter(i => i.MatchStatus === 'Cleared').length;
  // Flagged Count (Total flagged issues requiring AP review)
  const flaggedCount = db.processedInvoices.filter(i => i.MatchStatus === 'Flagged' || i.MatchStatus === 'Failed').length;

  // Invoices eligible for Batch Approval (satisfied strict 3-way match rules but not yet marked Cleared)
  const matchedPendingCount = db.processedInvoices.filter((inv) => {
    if (inv.MatchStatus === 'Cleared') return false;
    const matchRes = performMatching(inv, {
      purchaseOrders: db.purchaseOrders,
      goodsReceivedNotes: db.goodsReceivedNotes,
      processedInvoices: []
    });
    return matchRes.status === 'Cleared';
  }).length;
  
  // Total Value Verified Today (Sum of cleared invoices processed today)
  const totalValueToday = invoicesProcessedToday
    .filter(i => i.MatchStatus === 'Cleared')
    .reduce((sum, i) => sum + i.Invoice_Amount, 0);

  // Total Value of all cleared invoices in the system
  const totalValueAllCleared = db.processedInvoices
    .filter(i => i.MatchStatus === 'Cleared')
    .reduce((sum, i) => sum + i.Invoice_Amount, 0);

  // Search filter
  const filteredData = () => {
    const q = searchQuery.toLowerCase().trim();
    if (activeTab === 'po') {
      return db.purchaseOrders.filter(
        p => p.PO_Number.toLowerCase().includes(q) || p.Supplier.toLowerCase().includes(q) || p.Item.toLowerCase().includes(q)
      );
    } else if (activeTab === 'grn') {
      return db.goodsReceivedNotes.filter(
        g => g.GRN_Number.toLowerCase().includes(q) || g.PO_Number.toLowerCase().includes(q)
      );
    } else if (activeTab === 'threeway') {
      return db.processedInvoices
        .filter(i => i.MatchStatus === 'Cleared')
        .filter(
          i => i.Invoice_Number.toLowerCase().includes(q) || i.Supplier.toLowerCase().includes(q) || i.PO_Number.toLowerCase().includes(q)
        );
    } else {
      let list = db.processedInvoices;
      if (statusFilter === 'pending') {
        list = list.filter(i => i.MatchStatus === 'Pending');
      } else if (statusFilter === 'cleared') {
        list = list.filter(i => i.MatchStatus === 'Cleared');
      } else if (statusFilter === 'flagged') {
        list = list.filter(i => i.MatchStatus === 'Flagged' || i.MatchStatus === 'Failed');
      }
      return list.filter(
        i => i.Invoice_Number.toLowerCase().includes(q) || i.Supplier.toLowerCase().includes(q) || i.PO_Number.toLowerCase().includes(q)
      );
    }
  };

  return (
    <div className="min-h-screen font-sans flex flex-col bg-slate-50 text-slate-900">
      {/* HEADER SECTION */}
      <header className="bg-white border border-slate-200 shadow-sm rounded-2xl mt-6 mx-4 md:mx-6">
        <div className="max-w-7xl mx-auto px-6 py-4 flex flex-col md:flex-row md:items-center md:justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-indigo-600 rounded-xl flex items-center justify-center shadow-md">
              <span className="p-1 text-white font-black font-mono text-sm tracking-tighter">3W</span>
            </div>
            <div>
              <h1 className="text-xl font-bold text-slate-800 tracking-tight">3-Way Match & Duplicate Detection</h1>
              <p className="text-xs text-slate-500 font-semibold uppercase tracking-wider">Accounts Payable Assistant</p>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-4">
            {/* Help trigger */}
            <button 
              onClick={() => setShowHelp(!showHelp)}
              className="flex items-center gap-1.5 px-3 py-1.5 bg-slate-50 hover:bg-slate-100 text-slate-700 rounded-lg text-xs font-semibold transition border border-slate-200"
            >
              <HelpCircle className="w-4 h-4 text-indigo-500" />
              Madam Lim's Helper Guide
            </button>

            {/* Local backup switch */}
            {user ? (
              <div className="flex items-center gap-3">
                <div className="text-right hidden sm:block">
                  <p className="text-sm font-semibold text-slate-800">{user.displayName || 'Madam Lim'}</p>
                  <p className="text-xs text-slate-400 font-medium">Accounts Payable Executive</p>
                </div>
                <div className="relative">
                  <div className="w-10 h-10 bg-slate-100 text-slate-700 rounded-full flex items-center justify-center border-2 border-slate-200 shadow-inner font-bold text-sm">
                    {user.displayName ? user.displayName.split(' ').map((n: string) => n[0]).join('').slice(0, 2).toUpperCase() : 'ML'}
                  </div>
                  <button 
                    onClick={handleLogout} 
                    className="absolute -top-1 -right-1 bg-red-50 hover:bg-red-100 text-red-600 p-1 rounded-full border border-red-200 transition" 
                    title="Log out"
                  >
                    <LogOut className="w-3 h-3" />
                  </button>
                </div>
              </div>
            ) : (
              <button 
                onClick={handleLogin}
                className="flex items-center gap-2 px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white font-bold rounded-lg text-xs transition shadow-md"
              >
                <FileSpreadsheet className="w-4 h-4" />
                Connect Google Account
              </button>
            )}
          </div>
        </div>
      </header>

      {/* HELP INSTRUCTIONS */}
      <AnimatePresence>
        {showHelp && (
          <motion.div 
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            className="bg-indigo-50/30 border-b border-slate-200 overflow-hidden mx-4 md:mx-6 rounded-2xl mt-4 border border-slate-200"
          >
            <div className="max-w-7xl mx-auto px-6 py-6 grid md:grid-cols-3 gap-6 text-slate-700 text-sm leading-relaxed">
              <div className="bg-white p-5 rounded-2xl shadow-sm border border-slate-200">
                <h3 className="font-bold text-slate-850 flex items-center gap-1.5 mb-2">
                  <span className="flex items-center justify-center w-6 h-6 bg-indigo-100 text-indigo-700 rounded-full text-xs font-bold">1</span>
                  Our 3-Way Match Rule
                </h3>
                <p className="text-xs text-slate-600 leading-relaxed">
                  Every supplier invoice must correspond to a valid <strong>Purchase Order (PO)</strong> and <strong>Goods Received Note (GRN)</strong>. We guarantee fairness: checking that the quantity billed does not exceed the physical receipt log, and the price matches the initial PO agreement exactly.
                </p>
              </div>
              <div className="bg-white p-5 rounded-2xl shadow-sm border border-slate-200">
                <h3 className="font-bold text-slate-850 flex items-center gap-1.5 mb-2">
                  <span className="flex items-center justify-center w-6 h-6 bg-indigo-100 text-indigo-700 rounded-full text-xs font-bold">2</span>
                  Duplicate Detection Rule
                </h3>
                <p className="text-xs text-slate-600 leading-relaxed">
                  We look for exact matches of invoice numbers from the same supplier, or any invoice with the exact same billing amount from the same supplier within the past 30 days. These are flagged conservatively to prevent double payment.
                </p>
              </div>
              <div className="bg-white p-5 rounded-2xl shadow-sm border border-slate-200">
                <h3 className="font-bold text-slate-850 flex items-center gap-1.5 mb-2">
                  <span className="flex items-center justify-center w-6 h-6 bg-indigo-100 text-indigo-700 rounded-full text-xs font-bold">3</span>
                  How to Proceed
                </h3>
                <p className="text-xs text-slate-600 leading-relaxed">
                  You do not process payments here. Review the matches. If flagged, use our non-accusatory advice to ask the right staff (such as <strong>purchasing</strong> for price issues or <strong>warehouse</strong> for missing units). Click <strong>"Confirm and Send to Payment List"</strong> to finalise.
                </p>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      <main className="flex-1 max-w-7xl w-full mx-auto p-4 md:p-6 flex flex-col gap-6">
        {/* GOOGLE SHEETS CONNECTION & ALERT CARDS */}
        <div className="bg-white rounded-2xl shadow-sm border border-slate-200 p-6">
          <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-6">
            <div className="flex items-start md:items-center gap-4">
              <div className={`p-3 rounded-xl shadow-inner ${isLocalMode ? 'bg-indigo-50 text-indigo-600' : 'bg-emerald-50 text-emerald-600'}`}>
                <Database className="w-6 h-6" />
              </div>
              <div>
                <h2 className="font-bold text-slate-800 flex flex-wrap items-center gap-2">
                  Database Link Status: 
                  <span className={`text-xs font-bold px-3 py-1 rounded-full uppercase tracking-wider ${isLocalMode ? 'bg-indigo-100 text-indigo-800' : 'bg-emerald-100 text-emerald-800'}`}>
                    {isLocalMode ? 'Local Practice Mode' : 'Connected to Google Sheets'}
                  </span>
                </h2>
                <p className="text-slate-500 text-xs mt-1">
                  {isLocalMode 
                    ? 'Using default hardware supplier tables. Sign in with Google to use spreadsheets.' 
                    : `Active Google Sheet database: ID: ${connectedSheetId?.slice(0, 12)}...`
                  }
                </p>
              </div>
            </div>

            {/* Connection Input Field */}
            <div className="flex flex-wrap items-center gap-3">
              {/* Local Excel Database Upload Option */}
              <div className="flex items-center gap-2">
                <input
                  type="file"
                  id="xlsx-db-upload"
                  accept=".xlsx, .xls"
                  onChange={handleXlsxUpload}
                  className="hidden"
                />
                <label
                  htmlFor="xlsx-db-upload"
                  className="px-4 py-2.5 bg-white hover:bg-indigo-50 text-indigo-700 border-2 border-indigo-100 rounded-xl text-xs font-bold transition flex items-center justify-center gap-1.5 cursor-pointer shadow-sm animate-none"
                  title="Upload POs and GRNs from local Excel file"
                >
                  <Upload className="w-4 h-4 text-indigo-500" />
                  Upload Database (.xlsx)
                </label>

                <button
                  onClick={handleClearAllRecords}
                  className="px-4 py-2.5 bg-rose-50 hover:bg-rose-100 text-rose-700 border-2 border-rose-100 rounded-xl text-xs font-bold transition flex items-center justify-center gap-1.5 cursor-pointer shadow-sm"
                  title="Clear all Purchase Orders, Goods Received Notes, and Processed Invoices"
                >
                  <Trash2 className="w-4 h-4 text-rose-600" />
                  Clear All Records
                </button>

                {isLocalMode && (
                  <button
                    onClick={handleResetSampleData}
                    className="px-4 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 border-2 border-slate-200 rounded-xl text-xs font-bold transition flex items-center justify-center gap-1.5 cursor-pointer shadow-sm"
                    title="Reset all tables back to sample hardware business data"
                  >
                    <RotateCcw className="w-4 h-4 text-slate-600" />
                    Reset Sample Data
                  </button>
                )}
              </div>

              {user ? (
                <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-3 w-full lg:w-auto">
                  <input
                    type="text"
                    value={sheetInput}
                    onChange={(e) => setSheetInput(e.target.value)}
                    placeholder="Paste Google Sheet URL or ID"
                    className="flex-grow sm:w-80 px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:ring-2 focus:ring-indigo-500 focus:outline-none placeholder-slate-400"
                  />
                  <button
                    onClick={handleConnectSheet}
                    disabled={isSheetLoading}
                    className="px-4 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-sm font-bold transition shadow-sm flex items-center justify-center gap-1.5 disabled:opacity-50"
                  >
                    {isSheetLoading ? <RefreshCw className="w-4 h-4 animate-spin" /> : 'Connect Sheet'}
                  </button>
                  <button
                    onClick={handleCreateTemplateSheet}
                    disabled={isSheetLoading}
                    className="px-4 py-2.5 bg-white hover:bg-indigo-50 text-indigo-700 border-2 border-indigo-100 rounded-xl text-xs font-bold transition flex items-center justify-center gap-1.5 disabled:opacity-50"
                    title="Creates a full templated sheet with POs, GRNs and Log rows in your Google Drive!"
                  >
                    Create Template Sheet
                  </button>
                </div>
              ) : (
                <p className="text-slate-500 text-xs font-medium">
                  👉 Log in above to link your physical business Google Sheets directly.
                </p>
              )}
            </div>
          </div>

          {/* Feedback messages */}
          {sheetError && (
            <div className="mt-4 p-4 bg-red-50 border border-red-200 text-red-800 rounded-xl text-xs flex items-center gap-2">
              <AlertTriangle className="w-4 h-4 text-red-500 flex-shrink-0" />
              <span>{sheetError}</span>
            </div>
          )}
          {actionSuccess && (
            <div className="mt-4 p-4 bg-emerald-50 border border-emerald-200 text-emerald-800 rounded-xl text-xs flex items-center justify-between gap-2">
              <div className="flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-600 flex-shrink-0" />
                <span>{actionSuccess}</span>
              </div>
              <button onClick={() => setActionSuccess(null)} className="text-emerald-950 font-bold hover:underline">Dismiss</button>
            </div>
          )}
          {connectedSheetId && !isLocalMode && (
            <div className="mt-4 flex flex-wrap items-center gap-3 text-xs border-t border-slate-100 pt-3">
              <span className="text-slate-400 font-medium">Google Sheet Actions:</span>
              <a 
                href={`https://docs.google.com/spreadsheets/d/${connectedSheetId}`} 
                target="_blank" 
                rel="noreferrer" 
                className="text-indigo-600 font-bold hover:text-indigo-700 inline-flex items-center gap-1 underline"
              >
                Open Google Sheet in New Tab
                <ExternalLink className="w-3.5 h-3.5" />
              </a>
              <span className="text-slate-200">|</span>
              <button 
                onClick={() => {
                  setConnectedSheetId(null);
                  setIsLocalMode(true);
                  setSheetInput('');
                  localStorage.removeItem('ap_connected_sheet_id');
                  alert('Disconnected from Google Sheet. Reverting to local practice mode.');
                }}
                className="text-red-600 font-bold hover:underline cursor-pointer"
              >
                Disconnect
              </button>
            </div>
          )}
        </div>

        {/* METRICS SUMMARY PANEL */}
        <section className="grid grid-cols-2 lg:grid-cols-4 gap-4">
          <div className="bg-white p-5 rounded-2xl border border-amber-200/80 shadow-sm flex items-center justify-between">
            <div>
              <p className="text-amber-700 text-xs font-bold uppercase mb-1 flex items-center gap-1">
                <span>⏳ Pending Invoices</span>
              </p>
              <h3 className="text-3xl font-black text-amber-700">{pendingCount}</h3>
              <p className="text-[10px] text-amber-600 font-medium mt-1 font-mono">
                ${pendingTotalAmount.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })} awaiting verification
              </p>
            </div>
            <div className="p-2.5 bg-amber-50 rounded-xl text-amber-600">
              <Clock className="w-5 h-5" />
            </div>
          </div>

          <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm flex items-center justify-between">
            <div>
              <p className="text-emerald-600 text-xs font-bold uppercase mb-1">Cleared / Approved</p>
              <h3 className="text-3xl font-black text-emerald-600">{clearedCount}</h3>
              <p className="text-[10px] text-emerald-500 font-medium mt-1">
                {invoicesProcessedToday.filter(i => i.MatchStatus === 'Cleared').length} approved today
              </p>
            </div>
            <div className="p-2.5 bg-emerald-50 rounded-xl text-emerald-600">
              <CheckCircle2 className="w-5 h-5" />
            </div>
          </div>

          <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm flex items-center justify-between">
            <div>
              <p className="text-red-600 text-xs font-bold uppercase mb-1">Flagged Issues</p>
              <h3 className="text-3xl font-black text-red-600">{flaggedCount}</h3>
              <p className="text-[10px] text-red-500 font-medium mt-1">
                {invoicesProcessedToday.filter(i => i.MatchStatus === 'Flagged').length} flagged today
              </p>
            </div>
            <div className="p-2.5 bg-red-50 rounded-xl text-red-600">
              <AlertTriangle className="w-5 h-5" />
            </div>
          </div>

          <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm flex items-center justify-between">
            <div>
              <p className="text-slate-500 text-xs font-bold uppercase mb-1">Verified Today</p>
              <h3 className="text-3xl font-black text-slate-800 font-mono">${totalValueToday.toFixed(2)}</h3>
              <p className="text-[10px] text-slate-400 font-medium mt-1">
                Total Cleared: ${totalValueAllCleared.toFixed(2)}
              </p>
            </div>
            <div className="p-2.5 bg-slate-100 rounded-xl text-slate-600">
              <TrendingUp className="w-5 h-5" />
            </div>
          </div>
        </section>

        {/* CORE WORK AREA: 2 COLUMN SPLIT */}
        <div className="grid lg:grid-cols-12 gap-6 items-start">
              {/* COLUMN 1: PO & GRN EXCEL UPLOAD MODULE (7 COLS) */}
          <div className="lg:col-span-7 bg-white rounded-2xl shadow-sm border border-slate-200 overflow-hidden">
            <div className="p-6 border-b border-slate-100 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <h2 className="text-lg font-bold text-slate-800 flex items-center gap-2">
                <span className="w-2 h-6 bg-indigo-600 rounded-full"></span>
                PO & GRN Database Upload (.xlsx / .csv)
              </h2>
              <div className="flex items-center gap-2">
                <span className="text-[11px] font-bold px-2.5 py-1 bg-indigo-50 text-indigo-700 rounded-lg border border-indigo-100">
                  Excel / CSV Auto-Parser
                </span>
              </div>
            </div>

            <div className="p-6 flex flex-col gap-5">
              {/* Excel Dropzone */}
              <div
                onClick={() => {
                  const el = document.getElementById('po-grn-excel-file-input');
                  if (el) el.click();
                }}
                className="border-2 border-dashed border-indigo-200 hover:border-indigo-400 bg-slate-50/60 hover:bg-indigo-50/20 rounded-2xl p-8 text-center cursor-pointer transition flex flex-col items-center justify-center min-h-52 group"
              >
                <input
                  type="file"
                  id="po-grn-excel-file-input"
                  onChange={handleXlsxUpload}
                  accept=".xlsx, .xls, .csv"
                  className="hidden"
                />
                
                <div className="p-4 bg-indigo-50 group-hover:bg-indigo-100 text-indigo-600 rounded-2xl mb-3 transition shadow-sm">
                  <FileSpreadsheet className="w-8 h-8" />
                </div>

                <h3 className="font-bold text-slate-800 text-base mb-1">
                  Upload Purchase Orders & Goods Received Notes
                </h3>
                <p className="text-xs text-slate-500 max-w-md leading-relaxed mb-4">
                  Drag & drop or click to select an Excel workbook (<span className="font-mono text-slate-700 font-semibold">.xlsx / .xls</span>) or CSV file containing <strong>Purchase Orders (PO)</strong> and <strong>Goods Received Notes (GRN)</strong>.
                </p>

                <div className="inline-flex items-center gap-2 px-4 py-2 bg-indigo-600 group-hover:bg-indigo-700 text-white rounded-xl text-xs font-bold transition shadow-sm">
                  <Upload className="w-4 h-4" />
                  Select Excel Database File
                </div>
              </div>

              {/* Database Live Stats Grid */}
              <div className="grid sm:grid-cols-2 gap-4 pt-2">
                <div className="bg-slate-50 p-4 rounded-xl border border-slate-200 flex items-center justify-between">
                  <div>
                    <span className="text-xs font-bold text-slate-400 uppercase tracking-wider block mb-1">Loaded Purchase Orders</span>
                    <span className="text-2xl font-black text-slate-800 font-mono">{db.purchaseOrders.length}</span>
                    <span className="text-[11px] text-slate-500 block mt-1">
                      {db.purchaseOrders.length > 0 ? `Latest: ${db.purchaseOrders[0].PO_Number} (${db.purchaseOrders[0].Supplier})` : 'No PO records loaded'}
                    </span>
                  </div>
                  <div className="p-2.5 bg-indigo-100 text-indigo-700 rounded-xl">
                    <FileText className="w-5 h-5" />
                  </div>
                </div>

                <div className="bg-slate-50 p-4 rounded-xl border border-slate-200 flex items-center justify-between">
                  <div>
                    <span className="text-xs font-bold text-slate-400 uppercase tracking-wider block mb-1">Loaded Goods Receipts</span>
                    <span className="text-2xl font-black text-slate-800 font-mono">{db.goodsReceivedNotes.length}</span>
                    <span className="text-[11px] text-slate-500 block mt-1">
                      {db.goodsReceivedNotes.length > 0 ? `Latest: ${db.goodsReceivedNotes[0].GRN_Number} (PO: ${db.goodsReceivedNotes[0].PO_Number})` : 'No GRN records loaded'}
                    </span>
                  </div>
                  <div className="p-2.5 bg-emerald-100 text-emerald-700 rounded-xl">
                    <CheckCircle2 className="w-5 h-5" />
                  </div>
                </div>
              </div>

              {/* Quick Database Tools */}
              <div className="flex flex-wrap items-center justify-between gap-3 pt-3 border-t border-slate-100">
                <div className="flex items-center gap-2">
                  <button
                    onClick={handleResetSampleData}
                    className="px-3.5 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl text-xs font-bold transition flex items-center gap-1.5 cursor-pointer"
                  >
                    <RotateCcw className="w-3.5 h-3.5" />
                    Reset Default Hardware Sample Data
                  </button>
                  <button
                    onClick={handleClearAllRecords}
                    className="px-3.5 py-2 bg-rose-50 hover:bg-rose-100 text-rose-700 rounded-xl text-xs font-bold transition flex items-center gap-1.5 cursor-pointer"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                    Clear PO & GRN Database
                  </button>
                </div>

                <div className="flex flex-wrap items-center gap-2">
                  <button
                    onClick={handleScanAPInvoices}
                    disabled={isSheetLoading}
                    className="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-bold transition flex items-center gap-1.5 cursor-pointer shadow-sm disabled:opacity-50"
                  >
                    <RefreshCw className={`w-3.5 h-3.5 ${isSheetLoading ? 'animate-spin' : ''}`} />
                    Scan AP Invoices Sheet for Changes
                  </button>
                  <button
                    onClick={handleExportThreeWayMatched}
                    disabled={isExporting}
                    className="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold transition flex items-center gap-1.5 cursor-pointer shadow-sm disabled:opacity-50"
                  >
                    {isExporting ? <RefreshCw className="w-3.5 h-3.5 animate-spin" /> : <Download className="w-3.5 h-3.5" />}
                    Export "Three Way Matched" to Google Sheet
                  </button>
                </div>
              </div>

            </div>
          </div>

          {/* COLUMN 2: RESULT & ACTION CARD (5 COLS) */}
          <div className="lg:col-span-5 flex flex-col gap-4">
            <div className="bg-white rounded-2xl shadow-sm border border-slate-200 overflow-hidden">
              <div className="p-6 border-b border-slate-100">
                <h2 className="text-lg font-bold text-slate-800 flex items-center gap-2">
                  <span className="w-2 h-6 bg-indigo-500 rounded-full"></span>
                  Verification Report
                </h2>
              </div>

              <div className="p-6">
                {!hasChecked ? (
                  /* Placeholder when no match has been run yet */
                  <div className="flex flex-col items-center justify-center text-center p-8 min-h-[400px]">
                    <div className="p-4 bg-slate-100 rounded-2xl text-slate-400 mb-4 shadow-inner">
                      <FileCheck className="w-10 h-10" />
                    </div>
                    <h3 className="text-slate-800 font-bold text-sm">Waiting for Verification</h3>
                    <p className="text-slate-500 text-xs max-w-xs mt-2 leading-relaxed">
                      Please enter invoice details manually or upload an invoice document, then click the verification button to trigger the automated 3-way check.
                    </p>
                  </div>
                ) : (
                  /* Report active card */
                  <div className="flex flex-col gap-5">
                    {matchingResult?.status === 'Cleared' ? (
                      /* CLEARED - GREEN CARD */
                      <div className="border border-emerald-200 bg-emerald-50/50 rounded-2xl p-5 shadow-sm">
                        <div className="flex justify-between items-start mb-3">
                          <span className="bg-emerald-600 text-white px-3.5 py-1 rounded-full text-[10px] font-bold uppercase tracking-wider">
                            Cleared / Verified
                          </span>
                          <span className="text-[10px] text-emerald-600 font-mono font-bold">Match Code: OK-3WAY</span>
                        </div>
                        <p className="text-sm text-emerald-950 font-semibold leading-relaxed">
                          {matchingResult.explanation}
                        </p>
                        <div className="mt-4 bg-white/70 p-4 rounded-xl border border-emerald-100">
                          <p className="text-emerald-800 text-xs leading-relaxed">
                            <strong className="block mb-1 text-emerald-900 font-bold">✅ Recommended Action:</strong>
                            {matchingResult.followUp}
                          </p>
                        </div>
                      </div>
                    ) : (
                      /* FLAGGED - RED/ORANGE CARD */
                      <div className="border-2 border-red-200 bg-red-50 rounded-2xl p-5 shadow-sm">
                        <div className="flex justify-between items-start mb-3">
                          <span className="bg-red-600 text-white px-3.5 py-1 rounded-full text-[10px] font-bold uppercase tracking-wider">
                            Flagged for Mismatch
                          </span>
                          <span className="text-[10px] text-red-500 font-mono font-bold">Match Code: AP-WARN</span>
                        </div>
                        <p className="text-sm text-red-950 font-semibold leading-relaxed">
                          {matchingResult?.explanation}
                        </p>
                        <div className="mt-4 bg-white/70 p-4 rounded-xl border border-red-100">
                          <p className="text-red-800 text-xs leading-relaxed">
                            <strong className="block mb-1 text-red-900 font-bold">⚠️ Required Action:</strong>
                            {matchingResult?.followUp}
                          </p>
                        </div>
                      </div>
                    )}

                    {/* MATCHING MATRIX RESULTS GRID */}
                    <div className="bg-slate-50 rounded-2xl p-5 border border-slate-200 flex flex-col gap-3">
                      <h4 className="text-xs font-bold text-slate-500 uppercase tracking-wider mb-1">
                        3-Way Analysis Parameters
                      </h4>

                      <div className="flex flex-col gap-1">
                        {/* Parameter 1: Supplier Check */}
                        <div className="flex items-center justify-between text-xs py-2 border-b border-slate-100">
                          <span className="text-slate-500 font-medium">Supplier Match</span>
                          {!matchingResult?.poDetails ? (
                            <span className="text-amber-700 font-bold bg-amber-100/50 px-2.5 py-0.5 rounded-lg border border-amber-200">Cannot Verify</span>
                          ) : matchingResult?.status === 'Cleared' || !matchingResult?.discrepancies.some(d => d.includes('Supplier')) ? (
                            <span className="text-emerald-700 font-bold bg-emerald-100/50 px-2.5 py-0.5 rounded-lg border border-emerald-200">Matches PO</span>
                          ) : (
                            <span className="text-red-700 font-bold bg-red-100/50 px-2.5 py-0.5 rounded-lg border border-red-200">Mismatch</span>
                          )}
                        </div>

                        {/* Parameter 2: Total Amount Check across PO & GRN */}
                        <div className="flex items-center justify-between text-xs py-2 border-b border-slate-100">
                          <span className="text-slate-500 font-medium">Total Amount vs PO & GRN</span>
                          {!matchingResult?.poDetails ? (
                            <span className="text-amber-700 font-bold bg-amber-100/50 px-2.5 py-0.5 rounded-lg border border-amber-200">Cannot Verify</span>
                          ) : matchingResult?.status === 'Cleared' || !matchingResult?.discrepancies.some(d => d.includes('Total') || d.includes('Amount') || d.includes('Value')) ? (
                            <span className="text-emerald-700 font-bold bg-emerald-100/50 px-2.5 py-0.5 rounded-lg border border-emerald-200">Matches Total Value</span>
                          ) : (
                            <span className="text-red-700 font-bold bg-red-100/50 px-2.5 py-0.5 rounded-lg border border-red-200">Amount Mismatch</span>
                          )}
                        </div>

                        {/* Parameter 4: Duplicate Check */}
                        <div className="flex items-center justify-between text-xs py-2">
                          <span className="text-slate-500 font-medium">Duplicate Check</span>
                          {matchingResult?.isDuplicate ? (
                            <span className="text-red-700 font-bold bg-red-100/50 px-2.5 py-0.5 rounded-lg border border-red-200">Potential Duplicate</span>
                          ) : (
                            <span className="text-emerald-700 font-bold bg-emerald-100/50 px-2.5 py-0.5 rounded-lg border border-emerald-200">Unique Invoice</span>
                          )}
                        </div>
                      </div>
                    </div>

                    {/* MANUAL CONFIRMATION SUBMISSION STEP (MANDATORY) */}
                    <div className="mt-2">
                      <button
                        onClick={handleConfirmAndSend}
                        className={`w-full py-4 text-white font-bold text-sm rounded-xl transition-all shadow-md hover:shadow-lg flex items-center justify-center gap-2 cursor-pointer ${
                          matchingResult?.status === 'Cleared' 
                            ? 'bg-emerald-600 hover:bg-emerald-750' 
                            : 'bg-red-600 hover:bg-red-700'
                        }`}
                      >
                        <CheckCircle2 className="w-4 h-4" />
                        Confirm and Send to Payment List
                      </button>
                      <p className="text-[10px] text-slate-400 text-center mt-2.5 leading-relaxed">
                        * Note: Every invoice, flagged or cleared, requires Madam Lim's physical verification before being logged to Sheets.
                      </p>
                    </div>

                  </div>
                )}
              </div>
            </div>
          </div>

        </div>

        {/* BOTTOM TABBED VIEWER: LOGS AND MASTER DATA */}
        <section className="bg-white rounded-2xl shadow-sm border border-slate-200 overflow-hidden">
          {/* Tab Selection */}
          <div className="p-5 border-b border-slate-100 flex flex-col md:flex-row md:items-center justify-between gap-4 bg-slate-50/50">
            <div className="flex flex-wrap items-center gap-1">
              <button
                onClick={() => { setActiveTab('threeway'); setSearchQuery(''); }}
                className={`px-4 py-2.5 text-xs font-bold rounded-xl transition-all flex items-center gap-1.5 ${activeTab === 'threeway' ? 'bg-emerald-600 text-white shadow-sm' : 'text-slate-600 hover:bg-slate-100'}`}
              >
                <CheckCircle2 className="w-3.5 h-3.5" />
                Three Way Matched ({clearedCount})
              </button>
              <button
                onClick={() => { setActiveTab('invoices'); setSearchQuery(''); }}
                className={`px-4 py-2.5 text-xs font-bold rounded-xl transition-all ${activeTab === 'invoices' ? 'bg-indigo-600 text-white shadow-sm' : 'text-slate-600 hover:bg-slate-100'}`}
              >
                Invoices Log ({db.processedInvoices.length})
              </button>
              <button
                onClick={() => { setActiveTab('po'); setSearchQuery(''); }}
                className={`px-4 py-2.5 text-xs font-bold rounded-xl transition-all ${activeTab === 'po' ? 'bg-indigo-600 text-white shadow-sm' : 'text-slate-600 hover:bg-slate-100'}`}
              >
                Purchase Orders ({db.purchaseOrders.length})
              </button>
              <button
                onClick={() => { setActiveTab('grn'); setSearchQuery(''); }}
                className={`px-4 py-2.5 text-xs font-bold rounded-xl transition-all ${activeTab === 'grn' ? 'bg-indigo-600 text-white shadow-sm' : 'text-slate-600 hover:bg-slate-100'}`}
              >
                Goods Received Notes ({db.goodsReceivedNotes.length})
              </button>
            </div>

            {/* Quick Actions & Live Search */}
            <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-2 w-full md:w-auto">
              <button
                onClick={handleScanAPInvoices}
                disabled={isSheetLoading}
                className="px-3.5 py-2 bg-indigo-50 hover:bg-indigo-100 text-indigo-700 border border-indigo-200 rounded-xl text-xs font-bold transition flex items-center justify-center gap-1.5 cursor-pointer shadow-sm disabled:opacity-50 whitespace-nowrap"
                title="Fetch latest invoice rows from Google Sheet AP Invoices tab and re-run 3-way match"
              >
                <RefreshCw className={`w-3.5 h-3.5 ${isSheetLoading ? 'animate-spin' : ''}`} />
                Scan AP Invoices Sheet
              </button>

              {/* Live Search */}
              <div className="relative w-full md:w-72">
                <span className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-slate-400">
                  <Search className="w-4 h-4" />
                </span>
                <input
                  type="text"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder={`Search ${activeTab === 'po' ? 'PO, Supplier or Item' : activeTab === 'grn' ? 'GRN or PO Number' : 'Invoices, Supplier or PO'}...`}
                  className="pl-9 pr-4 py-2.5 border border-slate-200 rounded-xl text-xs w-full focus:ring-2 focus:ring-indigo-500 focus:outline-none bg-white placeholder-slate-400"
                />
              </div>
            </div>
          </div>

          {/* INVOICE STATUS FILTERS & AUTO-SYNC BAR */}
          {(activeTab === 'invoices' || activeTab === 'threeway') && (
            <div className="px-5 py-3 bg-slate-100/60 border-b border-slate-200 flex flex-wrap items-center justify-between gap-3">
              <div className="flex flex-wrap items-center gap-1.5">
                <span className="text-[11px] font-bold text-slate-500 uppercase tracking-wider mr-1">Filter:</span>
                <button
                  onClick={() => setStatusFilter('all')}
                  className={`px-3 py-1.5 text-xs font-bold rounded-lg transition-all ${statusFilter === 'all' ? 'bg-slate-800 text-white shadow-sm' : 'bg-white text-slate-600 hover:bg-slate-200'}`}
                >
                  All ({db.processedInvoices.length})
                </button>
                <button
                  onClick={() => setStatusFilter('pending')}
                  className={`px-3 py-1.5 text-xs font-bold rounded-lg transition-all flex items-center gap-1.5 ${statusFilter === 'pending' ? 'bg-amber-600 text-white shadow-sm' : 'bg-amber-50 text-amber-800 border border-amber-200 hover:bg-amber-100'}`}
                >
                  <span>⏳ Pending Verification</span>
                  <span className={`px-1.5 py-0.2 rounded-full text-[10px] font-mono font-bold ${statusFilter === 'pending' ? 'bg-amber-700 text-white' : 'bg-amber-200 text-amber-900'}`}>{pendingCount}</span>
                </button>
                <button
                  onClick={() => setStatusFilter('cleared')}
                  className={`px-3 py-1.5 text-xs font-bold rounded-lg transition-all ${statusFilter === 'cleared' ? 'bg-emerald-600 text-white shadow-sm' : 'bg-emerald-50 text-emerald-800 border border-emerald-200 hover:bg-emerald-100'}`}
                >
                  Cleared ({clearedCount})
                </button>
                <button
                  onClick={() => setStatusFilter('flagged')}
                  className={`px-3 py-1.5 text-xs font-bold rounded-lg transition-all ${statusFilter === 'flagged' ? 'bg-red-600 text-white shadow-sm' : 'bg-red-50 text-red-800 border border-red-200 hover:bg-red-100'}`}
                >
                  Flagged ({flaggedCount})
                </button>

                <div className="h-4 w-px bg-slate-300 mx-1 hidden sm:block"></div>

                <button
                  onClick={handleBatchApproveMatched}
                  className="px-3.5 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold transition flex items-center gap-1.5 shadow-xs cursor-pointer"
                  title="Approve all invoices that meet strict 3-way match rules with Purchase Orders and Goods Receipts"
                >
                  <CheckCheck className="w-3.5 h-3.5 text-emerald-200" />
                  <span>Batch Approve Matched</span>
                  {matchedPendingCount > 0 && (
                    <span className="px-1.5 py-0.2 bg-emerald-800 text-emerald-100 rounded-full text-[10px] font-mono font-bold">
                      {matchedPendingCount} ready
                    </span>
                  )}
                </button>
              </div>

              {user && (
                <div className="flex items-center gap-2 text-xs text-emerald-800 bg-emerald-50 px-3 py-1 rounded-xl border border-emerald-200 font-medium">
                  <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span>
                  <span>Auto-sync active (30s interval)</span>
                  {lastRefreshedTime && <span className="text-slate-400 font-mono text-[10px]">&bull; Last check: {lastRefreshedTime}</span>}
                  <button
                    onClick={() => token && loadSheetData(connectedSheetId || DEFAULT_SPREADSHEET_ID, token, false)}
                    disabled={isSheetLoading}
                    className="p-1 hover:bg-emerald-100 rounded-md transition ml-1 cursor-pointer"
                    title="Force refresh Google Sheet now"
                  >
                    <RefreshCw className={`w-3.5 h-3.5 text-emerald-700 ${isSheetLoading ? 'animate-spin' : ''}`} />
                  </button>
                </div>
              )}
            </div>
          )}

          {/* Master Table Display */}
          <div className="overflow-x-auto">
            {activeTab === 'threeway' && (
              <div className="flex flex-col">
                <div className="p-4 bg-emerald-50/60 border-b border-emerald-100 flex flex-col sm:flex-row items-center justify-between gap-3 px-6">
                  <div className="flex items-center gap-2">
                    <CheckCircle2 className="w-5 h-5 text-emerald-600" />
                    <div>
                      <h4 className="text-xs font-bold text-emerald-900 uppercase tracking-wider">3-Way Matched & Verified Invoices ({filteredData().length})</h4>
                      <p className="text-[11px] text-emerald-700">All invoices where Total Amount and Supplier match active PO & GRN records.</p>
                    </div>
                  </div>
                  <button
                    onClick={handleExportThreeWayMatched}
                    disabled={isExporting}
                    className="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold rounded-xl transition flex items-center gap-1.5 shadow-sm cursor-pointer disabled:opacity-50"
                  >
                    {isExporting ? <RefreshCw className="w-3.5 h-3.5 animate-spin" /> : <Download className="w-3.5 h-3.5" />}
                    Export "Three Way Matched" Tab to Google Sheet
                  </button>
                </div>

                <table className="min-w-full divide-y divide-slate-200 text-sm">
                  <thead className="bg-slate-50 text-slate-500 text-[10px] font-bold uppercase tracking-wider text-left border-b border-slate-200">
                    <tr>
                      <th className="px-6 py-4">Invoice Number</th>
                      <th className="px-6 py-4">Supplier</th>
                      <th className="px-6 py-4">PO Number</th>
                      <th className="px-6 py-4 text-right">Billed Amount</th>
                      <th className="px-6 py-4">Processed Date</th>
                      <th className="px-6 py-4 text-center">3-Way Match</th>
                      <th className="px-6 py-4 text-center">Status</th>
                      <th className="px-6 py-4 text-center">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="bg-white divide-y divide-slate-100 text-slate-700">
                    {filteredData().map((row: any, idx) => {
                      const matchRes = performMatching(row, {
                        purchaseOrders: db.purchaseOrders,
                        goodsReceivedNotes: db.goodsReceivedNotes,
                        processedInvoices: []
                      });
                      const is3WaySuccess = matchRes.status === 'Cleared';

                      return (
                        <tr key={idx} className="hover:bg-slate-50/50 transition align-top">
                          <td className="px-6 py-4 font-mono font-bold text-indigo-600">{row.Invoice_Number}</td>
                          <td className="px-6 py-4 max-w-sm">
                            <div className="font-bold text-slate-850">{row.Supplier}</div>
                            <div className="text-[10px] text-slate-500 mt-2 bg-slate-50 p-2.5 rounded-xl leading-relaxed font-sans border border-slate-100">{row.Explanation}</div>
                          </td>
                          <td className="px-6 py-4 font-mono font-bold text-slate-600">{row.PO_Number}</td>
                          <td className="px-6 py-4 text-right font-mono font-bold text-slate-850">${Number(row.Invoice_Amount).toFixed(2)}</td>
                          <td className="px-6 py-4 text-slate-500 text-xs font-medium">{row.Date_Processed}</td>
                          <td className="px-6 py-4 text-center min-w-[140px]">
                            {is3WaySuccess ? (
                              <span className="inline-flex items-center gap-1 text-[10px] font-bold font-mono tracking-wider px-2.5 py-1 rounded-full uppercase bg-emerald-100 text-emerald-800 border border-emerald-200">
                                <CheckCircle2 className="w-3 h-3 text-emerald-600" /> Matched
                              </span>
                            ) : (
                              <div className="flex flex-col items-center gap-1">
                                <span className="inline-flex items-center gap-1 text-[10px] font-bold font-mono tracking-wider px-2.5 py-1 rounded-full uppercase bg-amber-100 text-amber-800 border border-amber-200">
                                  <AlertTriangle className="w-3 h-3 text-amber-600" /> Discrepancy
                                </span>
                                {matchRes.discrepancies && matchRes.discrepancies.length > 0 && (
                                  <div className="text-[10px] text-amber-900 bg-amber-50 p-2 rounded-lg border border-amber-200/60 text-left max-w-xs mt-1 font-sans leading-tight">
                                    {matchRes.discrepancies.map((d, dIdx) => (
                                      <p key={dIdx} className="mb-0.5 last:mb-0">• {d}</p>
                                    ))}
                                  </div>
                                )}
                              </div>
                            )}
                          </td>
                          <td className="px-6 py-4 text-center">
                            <span className="inline-block text-[10px] font-bold font-mono tracking-wider px-3 py-1 rounded-full uppercase bg-emerald-100 text-emerald-800 border border-emerald-200">
                              Cleared
                            </span>
                          </td>
                          <td className="px-6 py-4 text-center">
                            <div className="flex items-center justify-center gap-1.5">
                              <button
                                onClick={() => handleApproveInvoice(row)}
                                className="px-2.5 py-1.5 text-xs font-bold rounded-xl transition flex items-center gap-1 cursor-pointer bg-emerald-600 text-white border border-emerald-700 shadow-xs"
                                title="Re-affirm manual approval"
                              >
                                <CheckCircle2 className="w-3.5 h-3.5" />
                                Approved
                              </button>
                              <button
                                onClick={() => handleDenyInvoice(row)}
                                className="px-2.5 py-1.5 text-xs font-bold rounded-xl transition flex items-center gap-1 cursor-pointer bg-rose-50 hover:bg-rose-600 text-rose-700 hover:text-white border border-rose-200 shadow-xs"
                                title="Manually deny / flag this invoice"
                              >
                                <XCircle className="w-3.5 h-3.5" />
                                Deny
                              </button>
                            </div>
                          </td>
                        </tr>
                      );
                    })}
                    {filteredData().length === 0 && (
                      <tr>
                        <td colSpan={8} className="px-6 py-12 text-center text-slate-400 font-medium">No 3-way matched invoices cleared yet.</td>
                      </tr>
                    )}
                  </tbody>
                </table>
              </div>
            )}

            {activeTab === 'po' && (
              <table className="min-w-full divide-y divide-slate-200 text-sm">
                <thead className="bg-slate-50 text-slate-500 text-[10px] font-bold uppercase tracking-wider text-left border-b border-slate-200">
                  <tr>
                    <th className="px-6 py-4">PO Number</th>
                    <th className="px-6 py-4">Supplier</th>
                    <th className="px-6 py-4">Item Description</th>
                    <th className="px-6 py-4 text-right">Qty Ordered</th>
                    <th className="px-6 py-4 text-right">Unit Price</th>
                    <th className="px-6 py-4 text-right">Total Est Value</th>
                  </tr>
                </thead>
                <tbody className="bg-white divide-y divide-slate-100 text-slate-700">
                  {filteredData().map((row: any, idx) => (
                    <tr key={idx} className="hover:bg-slate-50/50 transition">
                      <td className="px-6 py-4 font-mono font-bold text-indigo-600">{row.PO_Number}</td>
                      <td className="px-6 py-4 font-semibold text-slate-850">{row.Supplier}</td>
                      <td className="px-6 py-4 text-slate-600">{row.Item}</td>
                      <td className="px-6 py-4 text-right font-mono font-medium">{row.Quantity_Ordered}</td>
                      <td className="px-6 py-4 text-right font-mono font-medium">${Number(row.Unit_Price).toFixed(2)}</td>
                      <td className="px-6 py-4 text-right font-mono font-bold text-slate-800">${(Number(row.Quantity_Ordered) * Number(row.Unit_Price)).toFixed(2)}</td>
                    </tr>
                  ))}
                  {filteredData().length === 0 && (
                    <tr>
                      <td colSpan={6} className="px-6 py-12 text-center text-slate-400 font-medium">No purchase orders found.</td>
                    </tr>
                  )}
                </tbody>
              </table>
            )}

            {activeTab === 'grn' && (
              <table className="min-w-full divide-y divide-slate-200 text-sm">
                <thead className="bg-slate-50 text-slate-500 text-[10px] font-bold uppercase tracking-wider text-left border-b border-slate-200">
                  <tr>
                    <th className="px-6 py-4">GRN Number</th>
                    <th className="px-6 py-4">PO Number</th>
                    <th className="px-6 py-4 text-right">Qty Received</th>
                    <th className="px-6 py-4 text-right">Receipt Date</th>
                  </tr>
                </thead>
                <tbody className="bg-white divide-y divide-slate-100 text-slate-700">
                  {filteredData().map((row: any, idx) => (
                    <tr key={idx} className="hover:bg-slate-50/50 transition">
                      <td className="px-6 py-4 font-mono font-bold text-indigo-600">{row.GRN_Number}</td>
                      <td className="px-6 py-4 font-mono font-bold text-slate-600">{row.PO_Number}</td>
                      <td className="px-6 py-4 text-right font-mono font-medium">{row.Quantity_Received}</td>
                      <td className="px-6 py-4 text-right font-medium">{row.Date_Received}</td>
                    </tr>
                  ))}
                  {filteredData().length === 0 && (
                    <tr>
                      <td colSpan={4} className="px-6 py-12 text-center text-slate-400 font-medium">No Goods Received Notes found.</td>
                    </tr>
                  )}
                </tbody>
              </table>
            )}

            {activeTab === 'invoices' && (
              <table className="min-w-full divide-y divide-slate-200 text-sm">
                <thead className="bg-slate-50 text-slate-500 text-[10px] font-bold uppercase tracking-wider text-left border-b border-slate-200">
                  <tr>
                    <th className="px-6 py-4">Invoice Number</th>
                    <th className="px-6 py-4">Supplier</th>
                    <th className="px-6 py-4">PO Number</th>
                    <th className="px-6 py-4 text-right">Billed Amount</th>
                    <th className="px-6 py-4">Processed Date</th>
                    <th className="px-6 py-4 text-center">3-Way Match</th>
                    <th className="px-6 py-4 text-center">Status</th>
                    <th className="px-6 py-4 text-center">Actions</th>
                  </tr>
                </thead>
                <tbody className="bg-white divide-y divide-slate-100 text-slate-700">
                  {filteredData().map((row: any, idx) => {
                    const matchRes = performMatching(row, {
                      purchaseOrders: db.purchaseOrders,
                      goodsReceivedNotes: db.goodsReceivedNotes,
                      processedInvoices: []
                    });
                    const is3WayPass = matchRes.status === 'Cleared';

                    return (
                      <tr key={idx} className="hover:bg-slate-50/50 transition align-top">
                        <td className="px-6 py-4 font-mono font-bold text-indigo-600">{row.Invoice_Number}</td>
                        <td className="px-6 py-4 max-w-sm">
                          <div className="font-bold text-slate-850">{row.Supplier}</div>
                          <div className="text-[10px] text-slate-500 mt-2 bg-slate-50 p-2.5 rounded-xl leading-relaxed font-sans border border-slate-100">{row.Explanation}</div>
                          {row.FollowUpAction && (
                            <div className="text-[10px] text-indigo-950 bg-indigo-50/50 p-2.5 rounded-xl mt-1.5 border border-indigo-100/30 leading-relaxed">
                              <strong>Follow Up:</strong> {row.FollowUpAction}
                            </div>
                          )}
                        </td>
                        <td className="px-6 py-4 font-mono font-bold text-slate-600">{row.PO_Number}</td>
                        <td className="px-6 py-4 text-right font-mono font-bold text-slate-800">${Number(row.Invoice_Amount).toFixed(2)}</td>
                        <td className="px-6 py-4 text-slate-500 text-xs font-medium">{row.Date_Processed}</td>
                        <td className="px-6 py-4 text-center min-w-[140px]">
                          {is3WayPass ? (
                            <span className="inline-flex items-center gap-1 text-[10px] font-bold font-mono tracking-wider px-2.5 py-1 rounded-full uppercase bg-emerald-100 text-emerald-800 border border-emerald-200">
                              <CheckCircle2 className="w-3 h-3 text-emerald-600" /> Matched
                            </span>
                          ) : (
                            <div className="flex flex-col items-center gap-1">
                              <span className="inline-flex items-center gap-1 text-[10px] font-bold font-mono tracking-wider px-2.5 py-1 rounded-full uppercase bg-amber-100 text-amber-800 border border-amber-200">
                                <AlertTriangle className="w-3 h-3 text-amber-600" /> Discrepancy
                              </span>
                              {matchRes.discrepancies && matchRes.discrepancies.length > 0 && (
                                <div className="text-[10px] text-amber-900 bg-amber-50 p-2 rounded-lg border border-amber-200/60 text-left max-w-xs mt-1 font-sans leading-tight">
                                  {matchRes.discrepancies.map((d, dIdx) => (
                                    <p key={dIdx} className="mb-0.5 last:mb-0">• {d}</p>
                                  ))}
                                </div>
                              )}
                            </div>
                          )}
                        </td>
                        <td className="px-6 py-4 text-center">
                          <span className={`inline-block text-[10px] font-bold font-mono tracking-wider px-3 py-1 rounded-full uppercase ${
                            row.MatchStatus === 'Cleared' 
                              ? 'bg-emerald-100 text-emerald-800 border border-emerald-200' 
                              : 'bg-red-100 text-red-800 border border-red-200'
                          }`}>
                            {row.MatchStatus}
                          </span>
                        </td>
                        <td className="px-6 py-4 text-center">
                          <div className="flex items-center justify-center gap-1.5">
                            <button
                              onClick={() => handleApproveInvoice(row)}
                              className={`px-2.5 py-1.5 text-xs font-bold rounded-xl transition flex items-center gap-1 cursor-pointer shadow-xs ${
                                row.MatchStatus === 'Cleared'
                                  ? 'bg-emerald-600 text-white border border-emerald-700'
                                  : 'bg-emerald-50 hover:bg-emerald-600 text-emerald-700 hover:text-white border border-emerald-200'
                              }`}
                              title="Manually approve this invoice"
                            >
                              <CheckCircle2 className="w-3.5 h-3.5" />
                              {row.MatchStatus === 'Cleared' ? 'Approved' : 'Approve'}
                            </button>
                            <button
                              onClick={() => handleDenyInvoice(row)}
                              className={`px-2.5 py-1.5 text-xs font-bold rounded-xl transition flex items-center gap-1 cursor-pointer shadow-xs ${
                                row.MatchStatus === 'Flagged'
                                  ? 'bg-rose-600 text-white border border-rose-700'
                                  : 'bg-rose-50 hover:bg-rose-600 text-rose-700 hover:text-white border border-rose-200'
                              }`}
                              title="Manually deny / flag this invoice"
                            >
                              <XCircle className="w-3.5 h-3.5" />
                              {row.MatchStatus === 'Flagged' ? 'Denied' : 'Deny'}
                            </button>
                          </div>
                        </td>
                      </tr>
                    );
                  })}
                  {filteredData().length === 0 && (
                    <tr>
                      <td colSpan={8} className="px-6 py-12 text-center text-slate-400 font-medium">No invoices logged yet. Verify your first invoice above!</td>
                    </tr>
                  )}
                </tbody>
              </table>
            )}
          </div>
        </section>
      </main>

      {/* FOOTER */}
      <footer className="bg-slate-900 text-slate-400 text-xs py-8 border-t border-slate-800">
        <div className="max-w-7xl mx-auto px-6 text-center flex flex-col md:flex-row md:items-center md:justify-between gap-4">
          <p className="font-medium">&copy; 2026 Madam Lim's AP Match Suite. Hardware Supplies Logistics.</p>
          <p className="font-mono text-slate-500 text-[11px] flex flex-wrap items-center justify-center gap-2">
            <span>Secure Enterprise Channel</span>
            <span>&bull;</span>
            <span>Dual Duplicate Engine</span>
            <span>&bull;</span>
            <span>Gemini AI Engine</span>
          </p>
        </div>
      </footer>

      {/* CUSTOM CONFIRMATION MODAL (IFRAME-SAFE) */}
      {confirmModal && confirmModal.isOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm">
          <div className="bg-white rounded-2xl max-w-md w-full border border-slate-200 shadow-2xl p-6 overflow-hidden animate-none">
            <div className="flex items-start gap-4">
              <div className="p-3 bg-indigo-50 rounded-xl text-indigo-600 flex-shrink-0">
                <AlertCircle className="w-6 h-6" />
              </div>
              <div className="flex-1">
                <h3 className="text-base font-bold text-slate-900 mb-1">
                  {confirmModal.title}
                </h3>
                <p className="text-xs text-slate-500 leading-relaxed">
                  {confirmModal.message}
                </p>
              </div>
            </div>
            
            <div className="mt-6 flex items-center justify-end gap-3 border-t border-slate-100 pt-4">
              <button
                type="button"
                onClick={() => setConfirmModal(null)}
                className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold rounded-xl transition cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={confirmModal.onConfirm}
                className="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold rounded-xl transition shadow-sm hover:shadow cursor-pointer"
              >
                Confirm Action
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
