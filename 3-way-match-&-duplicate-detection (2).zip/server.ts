import express from 'express';
import path from 'path';
import { createServer as createViteServer } from 'vite';
import { GoogleGenAI, Type } from '@google/genai';
import dotenv from 'dotenv';

// Load environment variables
dotenv.config();

const PORT = 3000;

// Lazy initialize Gemini client to avoid crashes if API Key is not set initially
let aiClient: GoogleGenAI | null = null;
function getGeminiClient() {
  if (!aiClient) {
    const apiKey = process.env.GEMINI_API_KEY;
    if (!apiKey) {
      throw new Error('GEMINI_API_KEY environment variable is required');
    }
    aiClient = new GoogleGenAI({
      apiKey,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build',
        },
      },
    });
  }
  return aiClient;
}

async function startServer() {
  const app = express();

  // Allow larger payloads for PDF/image base64 uploads
  app.use(express.json({ limit: '50mb' }));
  app.use(express.urlencoded({ limit: '50mb', extended: true }));

  // API Route: Health check
  app.get('/api/health', (req, res) => {
    res.json({ status: 'ok', time: new Date().toISOString() });
  });

  // API Route: Parse Invoice via Gemini
  app.post('/api/parse-invoice', async (req, res) => {
    try {
      const { base64Data, mimeType, textContent } = req.body;

      if (!textContent && (!base64Data || !mimeType)) {
        return res.status(400).json({ error: 'Missing base64Data/mimeType or textContent' });
      }

      const ai = getGeminiClient();

      const contents: any[] = [];
      if (base64Data && mimeType) {
        contents.push({
          inlineData: {
            mimeType: mimeType,
            data: base64Data,
          },
        });
      }
      if (textContent) {
        contents.push({
          text: `Document Content (Spreadsheet/Text):\n${textContent}`,
        });
      }

      const prompt = `You are an expert document parser for supplier hardware invoices. 
Extract the details from this invoice accurately.
Ensure you return numbers as floats/integers.
Always extract the Purchase Order number (PO Number) from the document (look for 'PO #', 'P.O. No.', 'Purchase Order', 'Ref PO', 'Customer PO', or patterns like PO-2026-001).
If PO number is missing or unstated, look for standard PO patterns or return an empty string if not found.`;

      contents.push(prompt);

      const response = await ai.models.generateContent({
        model: 'gemini-3.5-flash',
        contents,
        config: {
          responseMimeType: 'application/json',
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              invoiceNumber: { 
                type: Type.STRING, 
                description: 'The invoice number or invoice identifier (e.g., INV-4521, 10294, etc.)' 
              },
              supplier: { 
                type: Type.STRING, 
                description: 'The supplier, business name, or company selling the items (e.g., Acme Metal Fasteners, BuildFast Timber Co.)' 
              },
              invoiceAmount: { 
                type: Type.NUMBER, 
                description: 'The total bill or invoice amount (e.g. 540.00)' 
              },
              quantityInvoiced: { 
                type: Type.INTEGER, 
                description: 'The total quantity of items billed on the invoice' 
              },
              unitPrice: { 
                type: Type.NUMBER, 
                description: 'The average unit price or specific item unit price on the invoice' 
              },
              poNumber: { 
                type: Type.STRING, 
                description: 'The reference Purchase Order number (e.g., PO-2026-001, PO-1001, PO-2026-002)' 
              },
            },
            required: ['invoiceNumber', 'supplier', 'invoiceAmount', 'quantityInvoiced', 'unitPrice', 'poNumber'],
          },
        },
      });

      const extractedText = response.text;
      if (!extractedText) {
        throw new Error('Gemini returned an empty response');
      }

      const parsedData = JSON.parse(extractedText);
      return res.json(parsedData);
    } catch (error: any) {
      console.error('Error parsing invoice:', error);
      const errMsg = String(error.message || '');
      const isQuotaError = 
        error.status === 429 || 
        errMsg.includes('429') || 
        errMsg.toLowerCase().includes('quota') || 
        errMsg.toLowerCase().includes('limit') || 
        errMsg.toLowerCase().includes('exhausted') || 
        (error.error && error.error.code === 429);
      
      const isOverloadedError =
        error.status === 503 ||
        errMsg.includes('503') ||
        errMsg.toLowerCase().includes('overloaded') ||
        errMsg.toLowerCase().includes('service unavailable') ||
        (error.error && error.error.code === 503);

      const responseStatus = isQuotaError ? 429 : (isOverloadedError ? 503 : 500);

      return res.status(responseStatus).json({ 
        error: error.message || 'Failed to parse invoice' 
      });
    }
  });

  // Vite middleware in Development
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    // Serve static files in Production
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Server running on http://0.0.0.0:${PORT}`);
  });
}

startServer().catch((err) => {
  console.error('Failed to start server:', err);
});
