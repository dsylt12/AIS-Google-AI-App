export interface PurchaseOrder {
  PO_Number: string;
  Supplier: string;
  Item: string;
  Quantity_Ordered: number;
  Unit_Price: number;
}

export interface GoodsReceivedNote {
  GRN_Number: string;
  PO_Number: string;
  Quantity_Received: number;
  Date_Received: string;
}

export interface ProcessedInvoice {
  Invoice_Number: string;
  Supplier: string;
  Invoice_Amount: number;
  Quantity_Invoiced: number;
  Unit_Price: number;
  PO_Number: string;
  Date_Processed: string;
  MatchStatus: 'Pending' | 'Cleared' | 'Flagged' | 'Failed';
  Explanation: string;
  FollowUpAction: string;
  ApprovedAt?: string; // date confirmed by Madam Lim
}

export interface MatchingResult {
  status: 'Cleared' | 'Flagged';
  discrepancies: string[];
  explanation: string;
  followUp: string;
  poDetails?: PurchaseOrder;
  grnDetails?: GoodsReceivedNote;
  isDuplicate?: boolean;
}

export interface DatabaseState {
  purchaseOrders: PurchaseOrder[];
  goodsReceivedNotes: GoodsReceivedNote[];
  processedInvoices: ProcessedInvoice[];
}
