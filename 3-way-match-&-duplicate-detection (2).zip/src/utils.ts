import { DatabaseState, MatchingResult, PurchaseOrder, GoodsReceivedNote, ProcessedInvoice } from './types';
import * as XLSX from 'xlsx';

export const INITIAL_MOCK_DATABASE: DatabaseState = {
  purchaseOrders: [
    {
      PO_Number: 'PO-2026-001',
      Supplier: 'Acme Metal Fasteners',
      Item: 'Hex Bolts M12 (Grade 8.8)',
      Quantity_Ordered: 500,
      Unit_Price: 1.20
    },
    {
      PO_Number: 'PO-2026-002',
      Supplier: 'BuildFast Timber Co.',
      Item: 'Premium Oak Planks 2x4 (8ft)',
      Quantity_Ordered: 200,
      Unit_Price: 8.50
    },
    {
      PO_Number: 'PO-2026-003',
      Supplier: 'MegaBrass Supplies',
      Item: 'Brass Couplings 1/2 inch',
      Quantity_Ordered: 1000,
      Unit_Price: 2.40
    },
    {
      PO_Number: 'PO-2026-004',
      Supplier: 'SafeLock Systems',
      Item: 'Industrial Brass Padlocks',
      Quantity_Ordered: 150,
      Unit_Price: 12.00
    },
    {
      PO_Number: 'PO-2026-005',
      Supplier: 'SteelCraft Industries',
      Item: 'Galvanized Metal Sheets 1x2m',
      Quantity_Ordered: 50,
      Unit_Price: 45.00
    }
  ],
  goodsReceivedNotes: [
    {
      GRN_Number: 'GRN-9901',
      PO_Number: 'PO-2026-001',
      Quantity_Received: 450, // Shortfall of 50
      Date_Received: '2026-07-03'
    },
    {
      GRN_Number: 'GRN-9902',
      PO_Number: 'PO-2026-002',
      Quantity_Received: 200, // Perfect match
      Date_Received: '2026-07-05'
    },
    {
      GRN_Number: 'GRN-9903',
      PO_Number: 'PO-2026-003',
      Quantity_Received: 1000, // Perfect match
      Date_Received: '2026-07-10'
    },
    {
      GRN_Number: 'GRN-9904',
      PO_Number: 'PO-2026-004',
      Quantity_Received: 120, // Shortfall of 30
      Date_Received: '2026-07-12'
    },
    {
      GRN_Number: 'GRN-9905',
      PO_Number: 'PO-2026-005',
      Quantity_Received: 50, // Perfect match
      Date_Received: '2026-07-15'
    }
  ],
  processedInvoices: [
    {
      Invoice_Number: 'INV-4520',
      Supplier: 'MegaBrass Supplies',
      Invoice_Amount: 2400.00,
      Quantity_Invoiced: 1000,
      Unit_Price: 2.40,
      PO_Number: 'PO-2026-003',
      Date_Processed: '2026-07-11',
      MatchStatus: 'Cleared',
      Explanation: 'Cleared. The invoice perfectly matches PO-2026-003 and GRN-9903.',
      FollowUpAction: 'No follow up needed. Payment is approved.'
    },
    {
      Invoice_Number: '8a3f91b0-2c7e-4e9a-b312-58f01c98a411',
      Supplier: 'Acme Metal Fasteners',
      Invoice_Amount: 540.00,
      Quantity_Invoiced: 450,
      Unit_Price: 1.20,
      PO_Number: 'PO-2026-001',
      Date_Processed: '2026-07-04',
      MatchStatus: 'Pending',
      Explanation: '',
      FollowUpAction: ''
    },
    {
      Invoice_Number: 'INV/2026/MB-9903',
      Supplier: 'MegaBrass Supplies',
      Invoice_Amount: 2400.00,
      Quantity_Invoiced: 1000,
      Unit_Price: 2.40,
      PO_Number: 'PO-2026-003',
      Date_Processed: '2026-07-11',
      MatchStatus: 'Cleared',
      Explanation: 'Cleared: Verified 3-way match with PO-2026-003 and GRN-9903.',
      FollowUpAction: 'Payment cleared.'
    },
    {
      Invoice_Number: 'SUP-LOCK-881',
      Supplier: 'SafeLock Systems',
      Invoice_Amount: 1440.00,
      Quantity_Invoiced: 120,
      Unit_Price: 12.00,
      PO_Number: 'PO-2026-004',
      Date_Processed: '2026-07-13',
      MatchStatus: 'Pending',
      Explanation: '',
      FollowUpAction: ''
    },
    {
      Invoice_Number: 'INV-8812',
      Supplier: 'BuildFast Timber Co.',
      Invoice_Amount: 1700.00,
      Quantity_Invoiced: 200,
      Unit_Price: 8.50,
      PO_Number: 'PO-2026-002',
      Date_Processed: '2026-07-06',
      MatchStatus: 'Cleared',
      Explanation: 'Cleared. The invoice perfectly matches PO-2026-002 and GRN-9902.',
      FollowUpAction: 'No follow up needed. Payment is approved.'
    }
  ]
};

export function getDaysBetween(date1Str: string, date2Str: string): number {
  const d1 = new Date(date1Str);
  const d2 = new Date(date2Str);
  if (isNaN(d1.getTime()) || isNaN(d2.getTime())) return 999;
  const diffTime = Math.abs(d2.getTime() - d1.getTime());
  return Math.ceil(diffTime / (1000 * 60 * 60 * 24));
}

export function normalizePONumber(po: string): string {
  if (!po) return '';
  let cleaned = po.trim().toUpperCase();

  // 1. Specific known corruption overrides
  if (cleaned === 'PO-2026-0-2-2') {
    return 'PO-2026-012';
  }
  if (cleaned.includes('0-2-2')) {
    cleaned = cleaned.replace('0-2-2', '012');
  }

  // 2. If po has digits-only or format like 2026012
  const digitsOnly = cleaned.replace(/\D/g, '');
  if (digitsOnly.length >= 5 && !cleaned.includes('-')) {
    const year = digitsOnly.slice(0, 4);
    const suffix = digitsOnly.slice(4).padStart(3, '0').slice(-3);
    return `PO-${year}-${suffix}`;
  }

  // 3. Normalize hyphens and spaces
  cleaned = cleaned.replace(/\s*-\s*/g, '-');

  // 4. Normalize leading zeros in standard PO suffix (e.g., PO-YYYY-NNN)
  const match = cleaned.match(/^(PO|TBMW|RF|GRN)?-?(\d{4})-(\d+)$/i);
  if (match) {
    const prefix = match[1] || 'PO';
    const year = match[2];
    const suffix = match[3];
    const paddedSuffix = suffix.padStart(3, '0');
    return `${prefix}-${year}-${paddedSuffix}`;
  }

  // Match without hyphens: e.g., PO202602 or PO-202602 or PO2026002
  const matchNoHyphen = cleaned.match(/^(PO|TBMW|RF|GRN)?-?(\d{4})(\d{1,3})$/i);
  if (matchNoHyphen) {
    const prefix = matchNoHyphen[1] || 'PO';
    const year = matchNoHyphen[2];
    const suffix = matchNoHyphen[3];
    const paddedSuffix = suffix.padStart(3, '0');
    return `${prefix}-${year}-${paddedSuffix}`;
  }

  return cleaned;
}

export function performMatching(
  invoice: {
    Invoice_Number: string;
    Supplier: string;
    Invoice_Amount: number;
    Quantity_Invoiced: number;
    Unit_Price: number;
    PO_Number: string;
    Date_Processed: string; // current date or selected invoice date
  },
  db: DatabaseState
): MatchingResult {
  const discrepancies: string[] = [];
  let status: 'Cleared' | 'Flagged' = 'Cleared';
  let isDuplicate = false;

  // 1. DUPLICATE CHECK
  // Same supplier + same invoice number, OR same supplier + same amount within 30 days
  const duplicateByNum = db.processedInvoices.find(
    (pi) =>
      pi.Supplier.trim().toLowerCase() === invoice.Supplier.trim().toLowerCase() &&
      pi.Invoice_Number.trim().toLowerCase() === invoice.Invoice_Number.trim().toLowerCase()
  );

  const duplicateByAmt = db.processedInvoices.find(
    (pi) =>
      pi.Supplier.trim().toLowerCase() === invoice.Supplier.trim().toLowerCase() &&
      Math.abs(pi.Invoice_Amount - invoice.Invoice_Amount) < 0.01 &&
      getDaysBetween(pi.Date_Processed, invoice.Date_Processed) <= 30
  );

  if (duplicateByNum) {
    status = 'Flagged';
    isDuplicate = true;
    discrepancies.push(`Duplicate invoice number: Invoice ${invoice.Invoice_Number} from ${invoice.Supplier} already exists in the records.`);
    return {
      status: 'Flagged',
      isDuplicate: true,
      discrepancies,
      explanation: `Flagged: Invoice ${invoice.Invoice_Number} from ${invoice.Supplier} already exists in the processed records.`,
      followUp: 'Please verify with our AP database records or follow up with the supplier\'s billing team to confirm if this is a duplicate transmission.'
    };
  }

  if (duplicateByAmt) {
    status = 'Flagged';
    isDuplicate = true;
    discrepancies.push(`Potential duplicate amount: An invoice from ${invoice.Supplier} for the same amount of $${invoice.Invoice_Amount.toFixed(2)} was already processed within the past 30 days on ${duplicateByAmt.Date_Processed}.`);
    return {
      status: 'Flagged',
      isDuplicate: true,
      discrepancies,
      explanation: `Flagged: Potential duplicate detected with a similar invoice from ${invoice.Supplier} for $${invoice.Invoice_Amount.toFixed(2)} processed on ${duplicateByAmt.Date_Processed}.`,
      followUp: 'Please check our processed invoice archives or follow up with the supplier\'s billing representative to confirm if this is a double-billing.'
    };
  }

  const normalizedInvoicePo = normalizePONumber(invoice.PO_Number);

  // 1. Find PO by PO Number first
  let po = db.purchaseOrders.find(
    (p) => normalizePONumber(p.PO_Number) === normalizedInvoicePo
  );

  // 2. Fallback: If PO is not found by PO Number (e.g. if PO number was missing in sheet), check if supplier matches a PO
  if (!po && invoice.Supplier) {
    po = db.purchaseOrders.find(
      (p) => p.Supplier.trim().toLowerCase() === invoice.Supplier.trim().toLowerCase()
    );
  }

  // 3. Find GRN using the effective PO Number
  const effectivePoNum = po ? normalizePONumber(po.PO_Number) : normalizedInvoicePo;
  const grn = db.goodsReceivedNotes.find(
    (g) => normalizePONumber(g.PO_Number) === effectivePoNum
  );

  // If PO is missing
  if (!po) {
    status = 'Flagged';
    return {
      status: 'Flagged',
      discrepancies: ['Purchase Order not found.'],
      explanation: `Flagged: Purchase Order ${invoice.PO_Number || '(unspecified)'} could not be found in our business records.`,
      followUp: 'Please follow up with our purchasing department to verify if this is a valid order or if the PO number was keyed in incorrectly.',
      grnDetails: grn
    };
  }

  // Verify Supplier Matches PO Supplier
  if (po.Supplier.trim().toLowerCase() !== invoice.Supplier.trim().toLowerCase()) {
    discrepancies.push(`Supplier mismatch: Invoice supplier is "${invoice.Supplier}", but PO supplier is "${po.Supplier}".`);
  }

  // If GRN is missing
  if (!grn) {
    status = 'Flagged';
    return {
      status: 'Flagged',
      discrepancies: ['Goods Received Note (GRN) not found.'],
      explanation: `Flagged: A Goods Received Note for PO ${invoice.PO_Number} does not exist yet.`,
      followUp: 'Please follow up with our warehouse team to confirm if the delivery has arrived or if the GRN is still pending entry.',
      poDetails: po
    };
  }

  // 3-WAY MATCH: TOTAL AMOUNT CHECK (Match total invoice amount against PO total and GRN received value)
  const poTotalAmount = po.Quantity_Ordered * po.Unit_Price;
  const grnTotalAmount = grn.Quantity_Received * po.Unit_Price;

  // Check if invoice total amount matches PO total amount
  if (Math.abs(invoice.Invoice_Amount - poTotalAmount) >= 0.01) {
    discrepancies.push(`PO Total Amount Mismatch: Invoice total is $${invoice.Invoice_Amount.toFixed(2)}, but PO total value is $${poTotalAmount.toFixed(2)}.`);
  }

  // Check if invoice total amount matches GRN received value
  if (Math.abs(invoice.Invoice_Amount - grnTotalAmount) >= 0.01) {
    discrepancies.push(`GRN Total Value Mismatch: Invoice total is $${invoice.Invoice_Amount.toFixed(2)}, but GRN total value is $${grnTotalAmount.toFixed(2)}.`);
  }

  // If there are discrepancies, flag it
  if (discrepancies.length > 0) {
    status = 'Flagged';
    
    // Construct plain-language under 3-sentence explanation
    let explanationText = `Flagged: `;
    const poAmtMismatch = Math.abs(invoice.Invoice_Amount - poTotalAmount) >= 0.01;
    const grnAmtMismatch = Math.abs(invoice.Invoice_Amount - grnTotalAmount) >= 0.01;
    const sMismatch = po.Supplier.trim().toLowerCase() !== invoice.Supplier.trim().toLowerCase();

    if (poAmtMismatch && grnAmtMismatch) {
      explanationText += `Invoice #${invoice.Invoice_Number} total of $${invoice.Invoice_Amount.toFixed(2)} does not match the approved PO total ($${poTotalAmount.toFixed(2)}) nor the GRN received value ($${grnTotalAmount.toFixed(2)}).`;
    } else if (grnAmtMismatch) {
      explanationText += `Invoice #${invoice.Invoice_Number} total of $${invoice.Invoice_Amount.toFixed(2)} exceeds the value of goods received on GRN (${grn.Quantity_Received} units = $${grnTotalAmount.toFixed(2)}).`;
    } else if (poAmtMismatch) {
      explanationText += `Invoice #${invoice.Invoice_Number} total of $${invoice.Invoice_Amount.toFixed(2)} differs from the approved Purchase Order total ($${poTotalAmount.toFixed(2)}).`;
    } else if (sMismatch) {
      explanationText += `Invoice #${invoice.Invoice_Number} is billed under supplier "${invoice.Supplier}", but the corresponding Purchase Order was issued to "${po.Supplier}".`;
    } else {
      explanationText += discrepancies.join(' ');
    }

    // Recommended follow-up action
    let followUpText = '';
    if (grnAmtMismatch) {
      followUpText = `Please check with the warehouse team to confirm if remaining goods for PO ${po.PO_Number} are expected before approving the full invoice total ($${invoice.Invoice_Amount.toFixed(2)}).`;
    } else if (poAmtMismatch) {
      followUpText = `Please verify with the purchasing team why the invoice total ($${invoice.Invoice_Amount.toFixed(2)}) differs from the approved PO total ($${poTotalAmount.toFixed(2)}).`;
    } else if (sMismatch) {
      followUpText = `Please verify why the supplier name on the invoice differs from the purchase order.`;
    } else {
      followUpText = `Please follow up with the warehouse or purchasing team to resolve total amount discrepancies.`;
    }

    return {
      status: 'Flagged',
      discrepancies,
      explanation: explanationText,
      followUp: followUpText,
      poDetails: po,
      grnDetails: grn
    };
  }

  // Perfect Match!
  return {
    status: 'Cleared',
    discrepancies: [],
    explanation: `Cleared: Invoice #${invoice.Invoice_Number} perfectly matches the Purchase Order (${po.Item}) and Goods Received Note values.`,
    followUp: 'No discrepancies detected. This invoice is verified and ready for payment processing approval.',
    poDetails: po,
    grnDetails: grn
  };
}

export interface ExtractedExcelInvoice {
  invoiceNumber: string;
  supplier: string;
  poNumber: string;
  quantityInvoiced: number;
  unitPrice: number;
  invoiceAmount: number;
}

export function parseExcelInvoiceData(data: ArrayBuffer): {
  items: ExtractedExcelInvoice[];
  csvText: string;
} {
  try {
    const workbook = XLSX.read(data, { type: 'array' });
    if (!workbook.SheetNames || workbook.SheetNames.length === 0) {
      return { items: [], csvText: '' };
    }

    const firstSheet = workbook.Sheets[workbook.SheetNames[0]];
    if (!firstSheet) return { items: [], csvText: '' };

    const csvText = XLSX.utils.sheet_to_csv(firstSheet);
    const jsonRows = XLSX.utils.sheet_to_json<any>(firstSheet);

    const normalizeKey = (s: string) => String(s || '').toLowerCase().replace(/[\s_\-$()]/g, '');
    const getVal = (row: any, searchKeys: string[]) => {
      if (!row || typeof row !== 'object') return '';
      const rowKeys = Object.keys(row);
      const normalizedSearchKeys = searchKeys.map(k => normalizeKey(k));
      for (const nk of normalizedSearchKeys) {
        const foundKey = rowKeys.find(rk => normalizeKey(rk) === nk);
        if (foundKey && row[foundKey] !== undefined && row[foundKey] !== null) {
          return row[foundKey];
        }
      }
      return '';
    };

    const items: ExtractedExcelInvoice[] = [];

    for (const row of jsonRows) {
      const invNo = String(getVal(row, ['invoice_number', 'invoicenumber', 'invoice_no', 'inv_no', 'invoice', 'inv', 'invoiceno', 'invoice_id']) || '').trim();
      const supp = String(getVal(row, ['supplier', 'vendor', 'supplier_name', 'company', 'vendor_name', 'biller']) || '').trim();
      const po = String(getVal(row, ['po_number', 'ponumber', 'po_no', 'po', 'purchase_order', 'ref_po', 'po #', 'po_num', 'purchaseorder', 'p.o. #', 'p.o. number', 'purchase_order_number', 'po_id']) || '').trim();
      const qtyRaw = getVal(row, ['quantity_invoiced', 'quantity', 'qty', 'billed_qty', 'qty_invoiced', 'item_qty', 'count']);
      const priceRaw = getVal(row, ['unit_price', 'price', 'unitprice', 'rate', 'unit_cost', 'cost']);
      const amtRaw = getVal(row, ['invoice_amount', 'amount', 'total', 'billed_amount', 'invoice_total', 'total_amount', 'subtotal']);

      const qty = qtyRaw !== '' && qtyRaw !== null ? parseInt(String(qtyRaw).replace(/[^0-9.-]/g, ''), 10) : 0;
      const price = priceRaw !== '' && priceRaw !== null ? parseFloat(String(priceRaw).replace(/[^0-9.-]/g, '')) : 0;
      let amt = amtRaw !== '' && amtRaw !== null ? parseFloat(String(amtRaw).replace(/[^0-9.-]/g, '')) : 0;

      if (!amt && !isNaN(qty) && !isNaN(price) && qty > 0 && price > 0) {
        amt = qty * price;
      }

      if (invNo || supp || po || (amt > 0) || (qty > 0)) {
        items.push({
          invoiceNumber: invNo,
          supplier: supp,
          poNumber: po ? normalizePONumber(po) : '',
          quantityInvoiced: isNaN(qty) ? 0 : qty,
          unitPrice: isNaN(price) ? 0 : price,
          invoiceAmount: isNaN(amt) ? 0 : amt,
        });
      }
    }

    return { items, csvText };
  } catch (err) {
    console.error('Error parsing excel invoice data:', err);
    return { items: [], csvText: '' };
  }
}
